#include "rans.h"
/* ###################### */
/* Discrete Distributions */
/* ###################### */


/* ######################### */
/* Continuous  Distributions */
/* ######################### */

/* standard normal density function */
double ndf(double t);

/* standard normal cumulative distribution function */
double nc(double x);

/* returns the inverse of cumulative normal distribution function
Reference> The Full Monte, by Boris Moro, Union Bank of Switzerland
                        RISK 1995(2)*/
double cndev(double u);


/* ####################################### */
/* two dimension Continuous  Distributions */
/* ####################################### */

double fxy(double x, double y, double a, double b, double rho);
double Ntwo(double a, double b, double rho);
double ND2(double a, double b, double rho);
