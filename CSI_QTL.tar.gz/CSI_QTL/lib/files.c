#include <stdio.h>
#include <stdlib.h>



FILE *open_f(char *filename, char mode)
{
  FILE *file;
  switch (mode)
    {
    case 'r':
      if ( (file=fopen(filename,"r")) == NULL) {
	fprintf(stderr, "Cannot open file %s.\n",filename);
	exit(1);
      }
      break;

    case 'w':
      if ( (file=fopen(filename,"w")) == NULL) {
	fprintf(stderr, "Cannot open file %s.\n",filename);
	exit(1);
      }
    default:
      if ( (file=fopen(filename,"a")) == NULL) {
	fprintf(stderr, "Cannot open file %s.\n",filename);
	exit(1);
      }
      break;
    }

  return file;
}
