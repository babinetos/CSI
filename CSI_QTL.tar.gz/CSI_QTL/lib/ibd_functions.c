

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "vars.h"
#include "math_functions.h"
#include "ibd_functions.h"
#include "rans.h"
#define MAXLEN 5000
/* ########################### */ 
/*      math routines       */
/* ########################### */ 


void swap_f(int *person)
{
  int temp;
  temp=person[0];
  person[0]=person[1];
  person[1]=temp;
}


void vec_elem_prod_f(int m,double *A,double *B, double *C, int s)
{
  int i;
  double D[100];
  
  for (i=0+s;i<m+s;i++)
    D[i]=A[i]*B[i];
  
  for (i=0+s;i<m+s;i++)
    C[i]= D[i];
  
  return;
}

double vec_prod_f(int m, double *A,double *B, int s)
  {
    int i,j,c;
    double sum=0;
    for (i=0+s;i<m+s;i++)
      sum +=A[i]*B[i];
    
    return sum;
  }


void vec_mat_prod_f(int m, double *A,double B[m][m], double *C, int s)
{
  int i,j,c;
  double D[100];
  
  for (i=0+s;i<m+s;i++)
    {
      D[i]=0;
      for(j=0+s;j<m+s;j++)      
	D[i]+=A[j]*B[j][i];
    }
  for (i=0+s;i<m+s;i++)
    C[i]= D[i];
  
  return;
}


/* ########################### */ 
/*      general routines       */
/* ########################### */ 

int split_to_nuclear_f(int families[max_members+1][7], int total,int founders, int nuclear_family[max_nuc_families+1][max_fam_members+1])
{
  int f,i,j,k,t,sum;
  int father, mother;
  f=0;
  /**************************************************************
   *  Separating individual pedigrees from the file             *
   *        with multiple pedigrees                             *
   **************************************************************/

  for(i=1;i<= total;i++)
    families[i][0] = 0;
  
  sum = 0;
  
  t =total-founders;
	 
  /**************************************************************
   *  Locating the different nuclear families in the pedigree   *
   **************************************************************/

  while( sum < t )
    {
      f++;
      j=1;
      
      /**************************************************************
       * Searching for Non founders and Identifying Parental IDs    *
       * And  Outputing their information                           *
       **************************************************************/
      
      while( families[j][2] == 0 &&  families[j][3]== 0 || families[j][0] == 1)
	j++;
      father = families[j][2];
      mother = families[j][3];
      
      /*************
       *  Father   *
       *************/
      k=1;
      while( families[k][1] !=  father)
	k++;
      
      nuclear_family[f][1] = k;
	     
      /*************
       *  Mother   *
       *************/
      
      k=1;
      while( families[k][1] !=  mother)
	k++;
      
      nuclear_family[f][2] = k;
      

      /*************
       * Children  *
       *************/
	     
	     
      j=2;
      for(k=1;k<=total;k++)
	if( families[k][2] == father &&   families[k][3] == mother)
	  {
	    j++;
	    nuclear_family[f][j]=k;
	    families[k][0]=1;
	  }
      nuclear_family[f][0]=j;
      
      /****************************************************************
       * Printing the Nuclear family. Notice that at this point we can *
       * add any kind of restriction on the family so we can choose    *
       * families which satisfy specific restrictions                  *
       *****************************************************************/
      sum = 0;
      for(i=1;i<=total;i++)
	sum +=  families[i][0];

    }

  return f;

}

/* ################################################# */ 

int read_ped_f(char *ped_file)
{
  int i,j,k,l,n,m,f,s1,s2,p,par,t,u;
  FILE *pedigree;

  double family_id, current_family;
  int families[max_members+1][7],family_genos[max_markers+1][max_fam_members+1][3];
  int nuclear_families[max_nuc_families+1][max_fam_members+1];
  int uninfo,members,founders,flag;
  int aff,aff_sibs;
  double h=.01;
 
  char line[MAXLEN];

  pedigree= fopen(ped_file ,"r");
  fgets(line, MAXLEN,pedigree);
  sscanf(line,"%lf",&current_family);
  i=word_cnt(line);
/*   j=mod_f(i,2); */
  add_info=5;
/*   if(j==1) */
/*     add_info=7; */
  j=(i-add_info)/2;
  if(j != markers)
    {
      printf("<<<<<< Error >>>>>> \n Markers in pedigree file    : %3d\t \n Markers in marker decription file: %3d\n",j,markers);
      exit(1);
    }  
  rewind(pedigree);
  founders = 0;
  members=0;
  flag = 1;


  for(p=0;p<3;p++)	
    parents[p]=0;	
  
  n=0;
  while (flag < 2)
    {

      if(fscanf(pedigree,"%lf",&family_id) != 1)
	{
	  family_id = -23;
	  flag++;
	}     
      if(family_id != current_family)
       {
	 f=split_to_nuclear_f(families,members,founders,nuclear_families);
	 t=0;
	 for(i=1;i<=f;i++)
	   {
	     
	     par=0;
	     for(p=1;p<3;p++)
	       par+=family_genos[0][nuclear_families[i][p]][0];
	     aff_sibs=0; 
	     for(j=3;j<= nuclear_families[i][0];j++)
	       {
		 aff=0;
		 if(families[nuclear_families[i][j]][5] == 2)
		   aff=1;
		 aff_sibs +=aff*family_genos[0][nuclear_families[i][j]][0];
		 
	       }

	     if(aff_sibs>=2)
	       {

		 for( s1=3;s1<nuclear_families[i][0];s1++)
		   if(family_genos[0][nuclear_families[i][s1]][0]*families[nuclear_families[i][s1]][5]==2)
		   {
 
		     for( s2=s1+1;s2<=nuclear_families[i][0];s2++)
		       if(family_genos[0][nuclear_families[i][s2]][0]*families[nuclear_families[i][s2]][5]==2)
		       {
			 n++;
			 t++;

			 for(p=1;p<3;p++)
			   for(m=0;m<=markers;m++)
			     for(j=0;j<3;j++)
			       genos[n][m][p][j]=family_genos[m][nuclear_families[i][p]][j];

			 for(m=0;m<=markers;m++)
			   for(j=0;j<3;j++)
			     genos[n][m][3][j]=family_genos[m][nuclear_families[i][s1]][j];

			 parents[par]++;
			 family_ids[n][0]=current_family+t*h;
			 family_ids[n][1]=(double)families[nuclear_families[i][1]][1];
			 family_ids[n][2]=(double)families[nuclear_families[i][2]][1];
			 family_ids[n][3]=(double)families[nuclear_families[i][s1]][1];
			 family_ids[n][4]=(double)families[nuclear_families[i][s2]][1];

			 for(m=0;m<=markers;m++)
			   for(j=0;j<3;j++)
			     genos[n][m][4][j]=family_genos[m][nuclear_families[i][s2]][j];
			
		       }
		   }
	       }
	   }
       	 

	 founders=0;
	 members =0;
	 current_family = family_id;
       }   
 
     members++;

    
     for(i=1;i<=add_info-1;i++)
	 fscanf(pedigree,"%d",&families[members][i]);

     if( families[members][2]== 0 && families[members][3] == 0)
       founders++;
    
     u=0;
     for(i=1;i<=markers;i++)
       {
	 for(j=1;j<3;j++)
	     fscanf(pedigree,"%d",&family_genos[i][members][j]);
	 if( family_genos[i][members][1]*family_genos[i][members][2] == 0)
	   u++;
       }

     family_genos[0][members][0]=1;
     if( (double)u > (double)p_mis*markers) 
	 family_genos[0][members][0]=0;  
    }
  return n;
  
}








/* ################################################# */ 

int read_marker_info_f(char *loc_file)
{
/*****************************************************************/
/*   this function reads the marker information. It takes as an  */
/*   argument the name of a file whose format is the one for the */
/*   standard linkage programs. If all given distances are less  */
/*   than .5, the function automatically assumes that they are   */
/*   recombination fractions, and converts them into cM.         */
/*****************************************************************/
  int i,j,check=0;
  char junk[5000];
  FILE *mark_info;

  mark_info = fopen(loc_file,"r"); 

  fscanf(mark_info,"%d%5000[^\n]",&markers,junk);
  markers--;
  fgetc(mark_info);
  fscanf(mark_info,"%5000[^\n]",junk);
  fgetc(mark_info);

 for(i=0;i<=markers;++i)
   fscanf(mark_info,"%d",&j);

 fscanf(mark_info,"%5000[^\n]",junk);
 fgetc(mark_info);
  for(i=1;i<=4;++i)
    {      
      fscanf(mark_info,"%5000[^\n]",junk);
      fgetc(mark_info);
    }
  for(i=1;i<=markers;++i)
    {
      fscanf(mark_info,"%d%d%200[^\n]",&j,&alleles[i],junk);
       for (j = 1; j<=alleles[i];j++)
	fscanf(mark_info,"%lf",&proportions[i][j]);
    }

  alleles[0]=1;
  proportions[0][1]=1;
  alleles[markers+1]=1;
  proportions[markers+1][1]=1;
 
  fscanf(mark_info,"%*d");
  fscanf(mark_info,"%200[^\n]",junk);
  fgetc(mark_info);
 distances[0]=0;
  for(i=0;i<markers;++i)
    {
      fscanf(mark_info,"%lf",&distances[i]);
      if(distances[i] <= 0)
	distances[i]=.000001;
  
      if(distances[i] < .5)
	check++;
    }

  if( check == markers)
    for(i=0;i<markers;++i)
      distances[i]=rec_to_cM_f(map,distances[i]);

  return markers;

  }

/* ################################################# */ 

int locations_f(int analysis,int mode,int points,int inter_locs,double incre,double offend, double *locations)
{
  int i,k,l,n,locs[max_markers+1];
  double temp,mark_locs[max_markers+2];

  if( analysis == 1 || mode == 1)
    {
      mark_locs[0]=distances[0]-offend;
      distances[0]=offend;
      distances[markers]=offend;
      n = markers;
      for( i=1;i<=n+1;i++)
	mark_locs[i]= distances[i-1]+mark_locs[i-1];
      temp= mark_locs[0];
     if(points == 1)
	{
	  k=0;
	  
	  for(i=0;i<=markers;++i)
	    {
	      locs[i]=inter_locs;
	      incre = distances[i]/locs[i];
	      if(incre <=0)
		{
		  locs[i]=0;
		}else
		  for(l=1;l<=locs[i];l++)
		    {
		      k++;
		      locations[k]=temp;
		      temp+=incre;
		      low_marker[k]=i;
		      closest_marker[k]=i;
		      if((locations[k] > (mark_locs[i]+mark_locs[i+1])/2 && i< markers) || i==0)
			closest_marker[k]=i+1;
		      if(l==1)
			mark_ranks[i]=k;
		    }
	    }

	}
 
   
      if(points == 0)
	{
	  k=0;
	  i=0;
	  while(i<=markers)
	    {
	      locs[i]=0;
	      temp=mark_locs[i];
	      mark_ranks[i]=k+1;
	      while( temp < mark_locs[i+1])
		{
		  locs[i]++;
		  k++;
		  locations[k]=temp;
		  temp+=incre;
		  low_marker[k]=i;
		  closest_marker[k]=i;
		  if((locations[k] > (mark_locs[i]+mark_locs[i+1])/2 && i< markers ) || i==0)
		    closest_marker[k]=i+1;
		}
	      i++;
	    }
	}
      i=markers;
      k++;
      locations[k]=temp;
      temp+=incre;
/*       locs[i]++;  */
      low_marker[k]=i;
      closest_marker[k]=i;
      mark_ranks[i+1]=k;
      if(offend==0)
	mark_ranks[i]=k;
      n = k;

    }else
      { 
	locations[0]=0;
	n = markers;
	for( i=1;i<=n;i++)
	  {
	    locations[i]= distances[i-1]+locations[i-1];
	    low_marker[i]=i;
	    mark_ranks[i]=i;
	    closest_marker[i]=i;
	  }
      }
  mark_ranks[0]=1;
  return n ;
  }

/* ################################################# */ 

double rec_to_cM_f(int func,double theta)
{
/*    Converts rec fractions to cM using the  */
/*    designated function (0=hald, 1=Kos)     */
  double d;
  
  if( func ==1)
    {
      d=.25*log((1+2*theta)/(1-2*theta))*100;
    }else
      {
	d=-.5*log(1-2*theta)*100;
      }

  return d;
}

double cM_to_rec_f(int func,double cM)
{
/*    Converts cM to rec fractions  using the  */
/*    designated function (0=hald, 1=Kos)      */
  double d;
  
  if( func ==1)
    {
      d=.5*tanh(2*cM/100);
    }else
      {
	d=.5*(1-exp(-2*cM/100));
      }
  return d;
}

/* ################################################# */ 
/* ################################################# */ 
/* ################################################# */ 
/* ########  Two Point Functions  ################## */ 
/* ################################################# */ 
/* ################################################# */ 
/* ################################################# */ 


int joint_prob_rel_f(double ibd[3],int alleles, double proportions[],double geno_prob[8])
{
  /* ######################################################## */
  /* This function gives the probabilities of the 7 IBS       */
  /* arrangements for two relatives                           */
  /* ######################################################## */


  int i,j,k,l,m,s;
 
 
 for(i=0;i <= 8;i++)
 	   geno_prob[i] = 0; 
	 
 /* Probabilities of specific genotypes, given the Arrangements*/

 /* State 1 */
 for(i=1;i<=alleles;i++)
   {
     for(s=0;s<3;s++)
          geno_prob[1] = geno_prob[1] + ibd[s]*pow(proportions[i],4-s);
    }


 /* State 2 */

 for (i=1;i<=alleles;i++)
   for(j=1;j<=alleles;j++)
     if(i !=j)
     {
   geno_prob[2] =  geno_prob[2] + 4*ibd[0]*pow(proportions[i],3)*proportions[j] + 2*ibd[1]*pow(proportions[i],2)*proportions[j] ;

     }

 /* State 3 */

   for (i=1;i<alleles;i++)
     for(j=i+1;j<=alleles;j++)
     {
 geno_prob[3] = geno_prob[3] + 2*pow(proportions[i],2) * pow(proportions[j],2)*ibd[0];

     }



 /* State 4 */


for (i=1;i<=alleles;i++)
   for(j=1;j<alleles;j++)
     if(i != j)
	for(l=j+1;l<=alleles;l++)
	if(i != l)
     {
 geno_prob[4] =  geno_prob[4] +  4 *  pow(proportions[i],2) * proportions[j]* proportions[l]*ibd[0];
     }




/* State 5 */

   for (i=1;i<alleles;i++)
     for(j=i+1;j<=alleles;j++)
     {
  geno_prob[5] = geno_prob[5]+ 4*pow(proportions[i],2) * pow(proportions[j],2)*ibd[0] + proportions[i]*proportions[j]*(proportions[i]+proportions[j])*ibd[1] + 2*proportions[i]*proportions[j]*ibd[2];

     }
 


 /* State 6 */

for (i=1;i<=alleles;i++)
   for(j=1;j<alleles;j++)
     if(i != j)
	for(l=j+1;l<=alleles;l++)
	if(i != l)
     {
  geno_prob[6] =  geno_prob[6]+8 *  pow(proportions[i],2) * proportions[j]* proportions[l]*ibd[0] +2* proportions[i]* proportions[j]* proportions[l]*ibd[1];
     }


 /* State 7 */

for (i=1;i<alleles-2;i++)
   for(j=i+1;j<alleles-1;j++)
	for(l=j+1;l<alleles;l++)
	  for(m=l+1;m<=alleles;m++)
     {
 geno_prob[7] =  geno_prob[7] +  24 * proportions[i] * proportions[j]* proportions[l]* proportions[m]*ibd[0];
     }

 return 0;
}




int new_cond_no_parents_f (int alleles, double proportions[], double cond_exp[2][4])
{
  /* This function gives the P(mIBD =i/geno)  */
  int i, j, k, l, m, s, t, cases, type, pheno[5];
  double conditional[3], s_ibd[3], temp, Ex2;
  double cond_state_probs[3];
  double temp_cond_exp[3][3];
  s_ibd[0] = .25;
  s_ibd[1] = .5;
  s_ibd[2] = .25;

  cases = pow (alleles, 4);


  for(i=1;i<3;i++)
    for(j=0;j<3;j++)
      temp_cond_exp[i][j] = 0;

 
  /* Probabilities of specific genotypes, given the Arrangements */
 /* State 1 */
  for (i = 1; i <= alleles; i++)
    {
      for (s = 0; s < 3; s++)
	cond_state_probs[s] = pow (proportions[i], 4 - s);
      
      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];     
      
    }
  
  
 /*  State 2 */

  for (i = 1; i <= alleles; i++)
    for (j = 1; j <= alleles; j++)
      if (i != j)
	{
	  cond_state_probs[0] = 4 * pow (proportions[i],3) * proportions[j];
	  cond_state_probs[1] = 2 * pow (proportions[i], 2) * proportions[j];
	  cond_state_probs[2] = 0;


      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];
	}





  /* State 3 */

  for (i = 1; i < alleles; i++)
    for (j = i + 1; j <= alleles; j++)
      {

	  cond_state_probs[0] =  2 * pow (proportions[i], 2) * pow (proportions[j], 2) * s_ibd[0];
	  cond_state_probs[1] = 0;
	  cond_state_probs[2] = 0;


      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];



     }


  /* State 4 */


  for (i = 1; i <= alleles; i++)
    for (j = 1; j < alleles; j++)
      if (i != j)
	for (l = j + 1; l <= alleles; l++)
	  if (i != l)
	    {


	  cond_state_probs[0] =  4 * pow (proportions[i], 2) * proportions[j] * proportions[l] * s_ibd[0];
	  cond_state_probs[1] = 0;
	  cond_state_probs[2] = 0;


      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];

	    }


 


/* State 5 */

  for (i = 1; i < alleles; i++)
    for (j = i + 1; j <= alleles; j++)
      {

	  cond_state_probs[0] = 4 * pow (proportions[i], 2) * pow (proportions[j],2);
	  cond_state_probs[1] = proportions[i] * proportions[j] * (proportions[i] + proportions[j]);
	  cond_state_probs[2] = 2 * proportions[i] * proportions[j] ;



      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];

     }


  /* State 6 */

  for (i = 1; i <= alleles; i++)
    for (j = 1; j < alleles; j++)
      if (i != j)
	for (l = j + 1; l <= alleles; l++)
	  if (i != l)
	    {
	      cond_state_probs[0] = 8 * pow (proportions[i],2) * proportions[j] * proportions[l];
	      cond_state_probs[1] = 2 * proportions[i] * proportions[j] * proportions[l];
	      cond_state_probs[2] =0;



      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];

	    }


  /* State 7 */

  for (i = 1; i < alleles - 2; i++)
    for (j = i + 1; j < alleles - 1; j++)
      for (l = j + 1; l < alleles; l++)
	for (m = l + 1; m <= alleles; m++)
	  {

	    cond_state_probs[0] = 24 * proportions[i] * proportions[j] * proportions[l] *proportions[m];
	    cond_state_probs[1] = 0;
	    cond_state_probs[2] =0;
      temp = 0;
      for (s = 0; s < 3; s++)
	temp += s_ibd[s] * cond_state_probs[s];
	
      if (temp != 0)
	for (s = 0; s < 3; s++)
	  conditional[s] = s_ibd[s] * cond_state_probs[s] / temp;

      
      temp = conditional[1] + 2*conditional[2];
      
      for(t=1;t<3;t++)
	for (s = 0; s < 3; s++)
	  temp_cond_exp[t][s] += pow(temp,t) *  cond_state_probs[s];

	  }

  for(t=0;t<2;t++)
    {
      cond_exp[t][0]=temp_cond_exp[t+1][0];
      cond_exp[t][1]=temp_cond_exp[t+1][1];
      cond_exp[t][2]=temp_cond_exp[t+1][1];
      cond_exp[t][3]=temp_cond_exp[t+1][2];
    }

  return 0;

}




/* ################################################# */ 



int new_cond_one_parent_f(int alleles, double proportions[],double expect[2][4])
{
 

  int i,j,k,l,n,p;
 double sum_stat,pow_stat; 
 double cond_probs[3];
 double cond_expect[3][3];


/* Calculating the components for each Possible (P1,S) states */


      for(i=0;i<3;i++)
	  cond_probs[i]=0;
      for(i=1;i<3;i++)
	  for(j=0;j<3;j++)
	      cond_expect[i][j]=0; 
/* Parental State P1=(ii)*/

 
/* Sibs state 1 (ii,ii) */
 for(i=1;i<=alleles;i++)
   {

     	   sum_stat = .5 + 2 * .5 / (1+proportions[i]);
	   

	   cond_probs[0]=pow(proportions[i],4);
	   cond_probs[1]=.5*pow(proportions[i],3)*(1+proportions[i]);
	   cond_probs[2]=pow(proportions[i],3);

	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	       cond_expect[p][2] += pow_stat * cond_probs[2]; 
	     }
   
} 




/* Sibs state 2 (ii,ij) */

 for(i=1;i<=alleles;i++)
   {
     for(j=1;j<=alleles;j++)
       if( i != j)
	 {
	  
	   sum_stat = .5; 


	   cond_probs[0]=2*pow(proportions[i],3)*proportions[j];
	   cond_probs[1]=pow(proportions[i],3)*proportions[j];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }

    }
   }	


 

/* Sibs state 5 (ij,ij) */
 

 for(i=1;i<=alleles;i++)
   { 

  for(j=1;j<=alleles;j++)
    if( j != i )
      {
	sum_stat = .5 +  2 * .5 / (1+proportions[j]);
	 
	   cond_probs[0]= pow(proportions[i],2)*pow(proportions[j],2);
	   cond_probs[1]=.5*pow(proportions[i],2)*proportions[j]*(1+proportions[j]);
	   cond_probs[2]= pow(proportions[i],2)*proportions[j];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	       cond_expect[p][2] += pow_stat * cond_probs[2]; 
	     }
      }
	
    }			  





/* Sibs state 6 (ij,ik) */

 for(i=1;i<=alleles;i++)
   {
   for(j=1;j<=alleles;j++)
       if( i != j)
	 {
	
	   sum_stat = .5;

	   for(l= j + 1;l<=alleles;l++)
	     if( l != i)
	       {

	   cond_probs[0]=2*pow(proportions[i],2)*proportions[j]*proportions[l];
	   cond_probs[1]=pow(proportions[i],2)*proportions[j]*proportions[l];

	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }
	       }
	 }
   }	

 
 /* Parental State P1=(ij)*/


 /* Sibs state 1 (ii,ii) */
 
 for(i=1;i<=alleles;i++)
   {
     for(j=1;j<=alleles;j++)
       if( j != i )
	 {
	   
	   sum_stat = proportions[i] / (1+proportions[i]) + 2* 1 / (1+proportions[i]);

	   cond_probs[1]=.5*pow(proportions[i],3)*proportions[j];
	   cond_probs[2]=pow(proportions[i],2)*proportions[j];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	       cond_expect[p][2] += pow_stat * cond_probs[2]; 
	     }
      }
     
   }







/* Sibs state 2 (ii,ij) */
 
for(i=1;i<=alleles;i++)
   {
  for(j=1;j<=alleles;j++)
    if( j != i )
      {
	sum_stat = (1+proportions[j]) / (1+proportions[i] + proportions[j]);


	   cond_probs[0]=2*pow(proportions[i],3)*proportions[j];
	   cond_probs[1]=pow(proportions[i],2)*proportions[j]*(1+proportions[j]);

	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }
      }
   }

/* Sibs state 3 (ii,ik) */

for(i=1;i<=alleles;i++)
   {
     for(j=1;j<=alleles;j++)
       if( j != i )
	 {
	
	   sum_stat = 1;
	   
	   for(l= 1;l<=alleles;l++)
             if( l != i && l !=j)
	       {
		 
		 
		 cond_probs[1]=pow(proportions[i],2)*proportions[j]*proportions[l];
		 
		 
		 for(p=1;p<3;p++)
		   {
		     pow_stat=pow(sum_stat,p);
		     cond_expect[p][1] += pow_stat * cond_probs[1];
		   }
	       }
	 }
     
   }



/* Sibs state 5 (ii,jj) */

for(i=1;i<=alleles;i++)
   {
     for(j=i+1;j<=alleles;j++)
      	 {
	
	   sum_stat = 0;

	   cond_probs[0]=2*pow(proportions[i],2)*pow(proportions[j],2);
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	     }
      }

   }




/* Sibs state 5 (ii,jk) */


for(i=1;i<=alleles;i++)
   {
     for(j=1;j<=alleles;j++)
       if( j !=i )
      	 {
	   sum_stat = 0;
	   for(l=1;l<=alleles;l++)
	     if(l != i && l != j)
	       {


	   cond_probs[0]=2*pow(proportions[i],2)*proportions[j]*proportions[l];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	     }

	       }
	 }

   }



/* Sibs state 6  (ij,ij) */

for(i=1;i<=alleles;i++)
   {
  for(j=i+1;j<=alleles;j++)
    {
	
      sum_stat = (pow(proportions[i],2)+pow(proportions[j],2))/((proportions[i]+proportions[j])*( 1 + proportions[i] + proportions[j])) + 2*1 /( 1 + proportions[i] + proportions[j]);

	   cond_probs[0]=2*pow(proportions[i],2)*pow(proportions[j],2);
	   cond_probs[1]=.5 * proportions[i]*proportions[j]*(pow(proportions[i],2)+ pow(proportions[j],2));
	   cond_probs[2]=proportions[i]*proportions[j]*(proportions[i]+ proportions[j]);

	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	       cond_expect[p][2] += pow_stat * cond_probs[2]; 
	     }
      }
   }




/* Sibs state 7  (ij,ik) */


for(i=1;i<=alleles;i++)
   {
  for(j=1;j<=alleles;j++)
    if( j != i )
      {
	sum_stat = proportions[j] / (proportions[i] + proportions[j]);

	for(l=1;l<=alleles;l++)
	  if( l != i &&  l != j )
	    {	 


	   cond_probs[0]=2*pow(proportions[i],2)*proportions[j]*proportions[l];
	   cond_probs[1]=proportions[i]*pow(proportions[j],2)*proportions[l];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }

	    }
      }
   }




/* Sibs state 8  (ik,ik) */

for(i=1;i<=alleles;i++)
   {
     for(j=1;j<=alleles;j++)
       if( j != i )
	 for(l=1;l<=alleles;l++)
	   if( l != i && l != j )
	     {
     	       sum_stat = proportions[l] / (1+proportions[l])+2*1 / (1+proportions[l]);  

	   cond_probs[1]=.5*proportions[i]*proportions[j]*pow(proportions[l],2);
	   cond_probs[2]=proportions[i]*proportions[j]*proportions[l];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	       cond_expect[p][2] += pow_stat * cond_probs[2];
	     }
	     }
   }
   


/* Sibs state 9  (ik,il) */

for(i=1;i<=alleles;i++)
   {
  for(j=1;j<=alleles;j++)
    if( j != i )
    for(l= 1;l<=alleles;l++)
      if( l != i && l != j )
	{
	  sum_stat =1;
	  for(n=l+1;n<=alleles;n++)
          if( n != i && n != j )
	    {

	   cond_probs[1]=proportions[i]*proportions[j]*proportions[l]*proportions[n];

	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }

	    }
	}
   }
  
/* Sibs state 10  (ik,jk) */

for(i=1;i<=alleles;i++)
   {
  for(j=i+1;j<=alleles;j++)
    for(l= 1;l<=alleles;l++)
	if( l != i && l != j)
	  {
	    sum_stat = 1 / (1+proportions[l]);

	   cond_probs[0]=2*proportions[i]*proportions[j]*pow(proportions[l],2);
	   cond_probs[1]=proportions[i]*proportions[j]*proportions[l];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	       cond_expect[p][1] += pow_stat * cond_probs[1];
	     }

	     }
   }
   


/* Sibs state 11  (ik,jl) */


 for(i=1;i<=alleles;i++)
   {
     for(j=i+1;j<=alleles;j++)
       if( j != i )	      
       for(l= 1;l<=alleles;l++)
	 if( l != i && l != j)
	   for( n =1;n <=alleles ; n++)
	     if( n != i && n != j && n != l)
	       {
		 sum_stat = 0 ;

	   
	   cond_probs[0]=2*proportions[i]*proportions[j]*proportions[l]*proportions[n];
	   for(p=1;p<3;p++)
	     {
	       pow_stat=pow(sum_stat,p);
	       cond_expect[p][0] += pow_stat * cond_probs[0];
	     }

	       }
   }


  for(i=0;i<2;i++)
    {
      expect[i][0]=cond_expect[i+1][0];
      expect[i][1]=cond_expect[i+1][1];
      expect[i][2]=cond_expect[i+1][1];
      expect[i][3]=cond_expect[i+1][2];
    }


 return 0;
}



/* ################################################# */ 


int new_cond_parents_f(int alleles, double proportions[],double expect[2][4])
{
 
  int i,j,k,l,p;
  double ibdp[3],sum_ibd[8][9];
  double p_geno[8];
  double conditional_ibs[8][3][9];
  double pow_stat;
  double cond_expect[3][3];
/*#########################################################*/
/*#########################################################*/
 /* This table gives the sum P(mibd=1|P,S)+2*P(mibd=2|P,S) */


 for(i=0;i<8;i++)
   for(j=0;j<9;j++)
     sum_ibd[i][j]=0;


 /* Parental IBD State 1*/

 sum_ibd[1][1]=1;

 /* Parental IBD State 2*/

 sum_ibd[2][1]=1.5;
 sum_ibd[2][2]=.5;
 sum_ibd[2][5]=1.5;

/* Parental IBD State 3*/

 sum_ibd[3][5]=1;

 /* Parental IBD State 4*/

 sum_ibd[4][5]=1.5;
 sum_ibd[4][6]=.5;

 /* Parental IBD State 5*/

 sum_ibd[5][1]=2;
 sum_ibd[5][2]=1;
 sum_ibd[5][3]=0;
 sum_ibd[5][5]=1;

 /* Parental IBD State 6*/

 sum_ibd[6][1]=2;
 sum_ibd[6][2]=1;
 sum_ibd[6][4]=0;
 sum_ibd[6][5]=2;
 sum_ibd[6][6]=0;
 sum_ibd[6][8]=1;

/* Parental IBD State 7*/

 sum_ibd[7][5]=2;
 sum_ibd[7][6]=1;
 sum_ibd[7][7]=0;



/*#########################################################*/
/*#########################################################*/


ibdp[0]=1;
ibdp[1]=0;
ibdp[2]=0;

 
  /* This table Gives the probabilities of the Sibs genotypes, 
given their parents genotypes, as well as the number of alleles 
they share IBD. i is for the parent genotype, j for the alleles 
shared IBD, and k  fo the children genotype*/

     for(i=1;i<8;i++)
     for(l=0;l<3;l++)
     for(k=1;k<9;k++)
      conditional_ibs[i][l][k]=0;

 /*Parental IBS State 1*/ 
conditional_ibs[1][0][1] = 1.0;
conditional_ibs[1][1][1] = 1.0;
conditional_ibs[1][2][1] = 1.0;

/*Parental IBS State 2*/ 
conditional_ibs[2][0][2] = 1.0;
conditional_ibs[2][1][1] = .25;
conditional_ibs[2][1][2] = .5;
conditional_ibs[2][1][5] = .25;
conditional_ibs[2][2][1] = .5;
conditional_ibs[2][2][5] = .5;

/*Parental IBS State 3*/
conditional_ibs[3][0][5] = 1.0;
conditional_ibs[3][1][5] = 1.0;
conditional_ibs[3][2][5] = 1.0;

/*Parental IBS State 4*/ 
conditional_ibs[4][0][6] = 1.0;
conditional_ibs[4][1][5] = .5;
conditional_ibs[4][1][6] = .5;
conditional_ibs[4][2][5] = 1.0;

/*Parental IBS State 5*/ 
conditional_ibs[5][0][3] = .5;
conditional_ibs[5][0][5] = .5;
conditional_ibs[5][1][2] = 1.0;
conditional_ibs[5][2][1] = .5;
conditional_ibs[5][2][5] = .5;

/*Parental IBS State 6*/ 
conditional_ibs[6][0][4] = .5;
conditional_ibs[6][0][6] = .5;
conditional_ibs[6][1][2] = .5;
conditional_ibs[6][1][8] = .5;
conditional_ibs[6][2][1] = .25;
conditional_ibs[6][2][5] = .75;

/*Parental IBS State 7*/ 
conditional_ibs[7][0][7] = 1.0;
conditional_ibs[7][1][6] = 1.0;
conditional_ibs[7][2][5] = 1.0;

    
    
 joint_prob_rel_f(ibdp,alleles,proportions,p_geno);

 for(p=1;p<3;p++)
   for(k=0;k<3;k++)
     cond_expect[p][k] =0;
 for(i=1;i<8;i++)
   for(j=1;j<9;j++)
       for(p=1;p<3;p++)
	 {
	   pow_stat = pow(sum_ibd[i][j],p);
	   for(k=0;k<3;k++)
	     cond_expect[p][k] += pow_stat*p_geno[i]*conditional_ibs[i][k][j];
	 }

  for(i=0;i<2;i++)
    {
      expect[i][0]=cond_expect[i+1][0];
      expect[i][1]=cond_expect[i+1][1];
      expect[i][2]=cond_expect[i+1][1];
      expect[i][3]=cond_expect[i+1][2];
    }



 return 0;
}



/* ################################################# */ 


int two_ibd_f(char *ped_file)
{
/*******************************************************************/
/*   this function reads the file with n families and calculates   */
/*   the number of nucliar families in the file, and also computes */
/*   twopoint IBD sharings at each marker for each pair of affected*/ 
/*   sib-pair                                                      */
/*******************************************************************/
  int i,j,k,l,n,m,f,s1,s2,p,par;
  int family[max_markers+1][5][3];
  FILE *pedigree;

  double family_id, current_family;
  int families[max_members+1][7],family_genos[max_markers+1][max_fam_members+1][3];
  int nuclear_families[max_nuc_families+1][max_fam_members+1];
  int uninfo,members,founders,flag;
  int aff,aff_sibs;

  pedigree= fopen(ped_file ,"r");
  fscanf(pedigree,"%lf",&current_family);
  rewind(pedigree);
  founders = 0;
  members=0;
  flag = 1;

  for(p=0;p<3;p++)	
    parents[p]=0;	

  n=0;
  while (flag < 2)
    {

      if(fscanf(pedigree,"%lf",&family_id) != 1)
	{
	  family_id = -23;
	  flag++;
	}     
     if(family_id != current_family)
       {
	 f=split_to_nuclear_f(families,members,founders,nuclear_families);
	 for(i=1;i<=f;i++)
	   {
	     aff_sibs=0; 
	     for(j=3;j<= nuclear_families[i][0];j++)
	       {
		 aff=0;
		 if(families[nuclear_families[i][j]][5] == 2)
		   aff=1;
		 aff_sibs +=aff*family_genos[0][nuclear_families[i][j]][0];
		 
	       }

	     if(aff_sibs>=2)
	       {
		 family[0][0][0]=(int)current_family;
		 for(p=1;p<3;p++)
		   family[0][p][0]=families[nuclear_families[i][p]][1];

		 par=0;
		 for(p=1;p<3;p++)
		   par+=family_genos[0][nuclear_families[i][p]][0];

		 for(p=1;p<3;p++)
		   for(m=1;m<=markers;m++)
		     for(j=1;j<3;j++)
		       family[m][p][j]=family_genos[m][nuclear_families[i][p]][j];

		 for( s1=3;s1<nuclear_families[i][0];s1++)
		   if(family_genos[0][nuclear_families[i][s1]][0]*families[nuclear_families[i][s1]][5]==2)
		   {

		     family[0][3][0]=families[nuclear_families[i][s1]][1];
		     for(m=1;m<=markers;m++)
		       for(j=1;j<3;j++)
			 family[m][3][j]=family_genos[m][nuclear_families[i][s1]][j];
 
		     for( s2=s1+1;s2<=nuclear_families[i][0];s2++)
		       if(family_genos[0][nuclear_families[i][s2]][0]*families[nuclear_families[i][s2]][5]==2)
		       {
			 n++;
			 parents[par]++;
			 family_ids[n][0]=current_family;
			 family_ids[n][1]=(double)families[nuclear_families[i][s1]][1];
			 family_ids[n][2]=(double)families[nuclear_families[i][s2]][1];

			 family[0][4][0]=families[nuclear_families[i][s2]][1];


			 for(m=1;m<=markers;m++)
			   for(j=1;j<3;j++)
			     family[m][4][j]=family_genos[m][nuclear_families[i][s2]][j];
				 
			 family_two_ibd_f(family,ibd_share[n]);					 
		       }
		   }
	       }
	   }
       	 

	 founders=0;
	 members =0;
	 current_family = family_id;
       }   
 
     members++;
    
     for(i=1;i<=add_info-1;i++)
       fscanf(pedigree,"%d",&families[members][i]);
     
     if( families[members][2]== 0 && families[members][3] == 0)
       founders++;
     
     uninfo=0;
     for(i=1;i<=markers;i++)
       {
	 for(j=1;j<3;j++)
	   {
	     fscanf(pedigree,"%d",&family_genos[i][members][j]);	     
	     uninfo+=family_genos[i][members][j];
	   }
       }
     family_genos[0][members][0]=1;
     if(uninfo==0)
       family_genos[0][members][0]=0;
    }
      

  return n;
  
}


/* ################################################# */ 

int family_two_ibd_f(int family[max_markers+1][5][3], double ibd[max_locs+1][3])
{
/*******************************************************************/
/*   this function takes a nuclear family with exactly two affected*/
/*   sibs and return the twopoint IBD sharing at each marker       */
/*******************************************************************/
  int i,j,k,l,m,n,par;
  double sum;
  double IBD[4];
  double cond_probs[4];


  for(i=0;i<4;i++)
   IBD[i] = .25;


  /* Conditional probabilities of the Family Genotypes, given IBD state */
      for(i=1;i<=markers;++i)
	{
	  for(k=0;k<4;k++)
	    cond_probs[k]=1;
	  l=1;
	  for( k=3;k<5;k++)
	    l*=family[i][k][1]*family[i][k][2];
	  if(l>0)
	    {
	      par=0;
	      for( k=1;k<3;k++)
		if( family[i][k][1]*family[i][k][2]!=0)
		  par++;
	      switch(par)
		{
		case 0:
		  /*No Parents */
		  sib_cond_state_prob_f(i,family[i], cond_probs);
		  break;
		case 1:
		  /*One Parent */
		  one_cond_state_prob_f(i,family[i], cond_probs);
		  break;
		case 2:
		  /*Two Parents */
		  par_cond_state_prob_f(family[i],cond_probs);
		  break;
		}
	    }

	      sum = 4*vec_prod_f(4,cond_probs,IBD,0);
	      if( sum > 0)
		{
		  ibd[mark_ranks[i]][0] = cond_probs[0]/sum;
		  ibd[mark_ranks[i]][1] = (cond_probs[1]+cond_probs[2])/sum;
		  ibd[mark_ranks[i]][2] = cond_probs[3]/sum;
		}else
		  {
		    for(j=0;j<4;j++)
		      ibd[mark_ranks[i]][j] = .25;
		    printf("<< Warning>> Mendelian Problem\n"); 
		    printf("Family:\t%7d  ",family[0][0][0]);
		    printf("Marker:\t%7d\n",i);
		    printf("Genotypes:\n");		    
		    for(j=1;j<5;j++)
		      {
			printf("indiv:\t%7d\t",family[0][j][0]);
			printf("%7d\t%7d\n",family[i][j][1],family[i][j][2]);
		      }
		  }
	}
      
  return 0;
  
}

/* ################################################# */ 



void sib_cond_state_prob_f(int marker,int family[5][3], double *cond_probs)
{
  /***********************************************************************/
  /* this function takes the genotypes of a nuclear family, w/o parental */
  /* information, and returns the P(G_S|V_i)                             */
  /***********************************************************************/

  int i,j,k,sum;
  int sibs[5],identical[5];
  double p[5];

  int check=0;
  for(i=0;i<5;i++)
    cond_probs[i]=.25;

  for(i=3;i<5;i++)
    if( family[i][1]*family[i][2] > 0 )
      check++;
  if( check == 2)
    {
      k=0;
      for(i=3;i<5;i++)
	for(j=1;j<3;j++)
	  {
	    k++;
	    sibs[k]=family[i][j];
	    identical[k]=0;
	  }
      
      sum=0;
      for(i=1;i<5;i++)
	{
	  for(j=1;j<5;j++)
	    if(i!=j)
	      if(sibs[i] == sibs[j])
		identical[i]++;
	  sum += identical[i];
	}
      
      
      if(sum == 12)
	{
	  cond_probs[0]=pow(proportions[marker][sibs[1]],4);
	  cond_probs[1]=pow(proportions[marker][sibs[1]],3);
	  cond_probs[2]=cond_probs[1];
	  cond_probs[3]=pow(proportions[marker][sibs[1]],2);
	}
      
      if(sum == 6)
	{
	  
	  for(i=1;i<5;i++)
	    {
	      if(identical[i] == 2)
		p[1]=proportions[marker][sibs[i]];
	      
	      if(identical[i] != 2)
		p[2]=proportions[marker][sibs[i]];
	    }
	  
	  cond_probs[0]=4*pow(p[1],3)*p[2];
	  cond_probs[1]=2*pow(p[1],2)*p[2];
	  cond_probs[2]=cond_probs[1];
	  cond_probs[3]=0;
	  
	} 
      
      if(sum == 4)
	{
	  
 
	  if( sibs[1] == sibs[2])
	    {
	      p[1]=proportions[marker][sibs[1]];
	      p[2]=proportions[marker][sibs[3]];
	      
	      cond_probs[0]=2*pow(p[1],2)*pow(p[2],2);
	      cond_probs[1]=0;
	      cond_probs[2]=cond_probs[1];
	      cond_probs[3]=0;
	      
	    }
	  else
	    {
	      p[1]=proportions[marker][sibs[1]];
	      p[2]=proportions[marker][sibs[2]];
	      
	      cond_probs[0]=4*pow(p[1],2)*pow(p[2],2);
	      cond_probs[1]=p[1]*p[2]*(p[1]+p[2]);
	      cond_probs[2]=cond_probs[1];
	      cond_probs[3]=2*p[1]*p[2];
	    }
	  
	}
      
      
      if(sum == 2)
	{
	  
	  k=2;
	  for(i=1;i<5;i++)
	    if(identical[i] != 1)
	      {
		p[k]=proportions[marker][sibs[i]];
		k++;
	      }
	  for(i=1;i<4;i++)
	    if(identical[i] == 1)
	      p[1]=proportions[marker][sibs[i]];
	  
	  
	  if( sibs[1] == sibs[2] || sibs[3] == sibs[4] )
	    {
	      cond_probs[0]=4*pow(p[1],2)*p[2]*p[3];
	      cond_probs[1]=0;
	      cond_probs[2]=cond_probs[1];
	      cond_probs[3]=0;
	    }
	  else 
	    {
	      cond_probs[0]=8*pow(p[1],2)*p[2]*p[3];
	      cond_probs[1]=2*p[1]*p[2]*p[3];
	      cond_probs[2]=cond_probs[1];
	      cond_probs[3]=0;
	    }  
	  
	}
      
      
      
      if(sum == 0)
	{
	  for(i=1;i<5;i++)
	    p[i]=proportions[marker][sibs[i]];
	  
	  cond_probs[0]=24*p[1]*p[2]*p[3]*p[4];
	  cond_probs[1]=0;
	  cond_probs[2]=cond_probs[1];
	  cond_probs[3]=0;

	}
    }
  return ;   

}




/* ################################################# */ 


void one_cond_state_prob_f(int marker,int family[5][3], double *cond_probs)
{
  /***********************************************************************/
  /* this function takes the genotypes of a nuclear family, w/ one parent*/
  /* and returns the P(G_S,P_1|V_i)                                          */
  /***********************************************************************/
  int i,j,k,par,dist,n_a;
  int distinct_alleles[2][5];
  int fam[7];
  double p[5],temp;

  int check=0;
  for(i=0;i<5;i++)
    cond_probs[i]=.25;

  for(i=3;i<5;i++)
    if( family[i][1]*family[i][2] > 0 )
      check++;
  if( check == 2)
    {
  par=1;
  if(family[1][1]*family[1][2]==0)
    par=2;

  for(j=1;j<3;j++)
    fam[j]=family[par][j];
  for(j=1;j<3;j++)
    fam[j+2]=family[3][j];
  for(j=1;j<3;j++)
    fam[j+4]=family[4][j];

 for(i=0;i<2;i++)
     for(j=1;j<5;j++)
       distinct_alleles[i][j]=0;


 distinct_alleles[0][1]=fam[1];
 distinct_alleles[1][1]++;

 n_a = 1;
 for(i=2;i<7;i++)
   {
      dist=0;
      for( j=1;j<=n_a;j++)
	if(fam[i]==distinct_alleles[0][j])
	  {
	    dist++;
	    distinct_alleles[1][j]++;
	  }
      if(dist == 0)
	{
	  n_a++;
	  distinct_alleles[0][n_a]=fam[i];
	  distinct_alleles[1][n_a]++;
	}
   }
       
 sort_f(n_a,distinct_alleles);

 if( fam[1]==fam[2])
   {
     switch(distinct_alleles[1][1])
	{
	case 6:
	  /* State 1 */
	  cond_probs[0]=pow(proportions[marker][distinct_alleles[0][1]],4);
	  cond_probs[1]=cond_probs[0];
	  cond_probs[2]=pow(proportions[marker][distinct_alleles[0][1]],3);
	  cond_probs[3]=cond_probs[2];
	  break;
	case 5:
	  /* State 2 */
	  cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],3)*proportions[marker][distinct_alleles[0][2]];
	  cond_probs[1]=cond_probs[0];
	  cond_probs[2]=0;
	  cond_probs[3]=0;
	  break;
	case 4:

	  if(distinct_alleles[1][2] == 2)
	    {
	      /* State 3 */
	      cond_probs[0]=pow(proportions[marker][distinct_alleles[0][1]],2)*pow(proportions[marker][distinct_alleles[0][2]],2);
	      cond_probs[1]=cond_probs[0];
	      cond_probs[2]=pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][2]];
	      cond_probs[3]=cond_probs[2];
	    }else
	      {
		/* State 4 */
		cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],3)*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
		cond_probs[1]=cond_probs[0];
		cond_probs[2]=0;
		cond_probs[3]=0;
	      }

	  break;
	}
   }else
     {

       switch(distinct_alleles[1][1])
	 {
	 case 5:
	   /* State 5 */
	   cond_probs[0]=0;
	   cond_probs[1]=pow(proportions[marker][distinct_alleles[0][1]],3)*proportions[marker][distinct_alleles[0][2]];
	   cond_probs[2]=0;
	   cond_probs[3]=pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][2]];
	   break;
	 case 4:
	   if(n_a == 2)
	     {
	       /* State 6 */
	       cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],3)*proportions[marker][distinct_alleles[0][2]];
	       cond_probs[1]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*pow(proportions[marker][distinct_alleles[0][2]],2);
	       cond_probs[2]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][2]];
	       cond_probs[3]=0;
	     }else
	       {
		 /* State 7 */
		 cond_probs[0]=0;
		 cond_probs[1]=pow(proportions[marker][distinct_alleles[0][1]],3)*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
		 cond_probs[2]=0;
		 cond_probs[3]=0;	 
	       }
	       break;
	     case 3:
	       if(distinct_alleles[1][2] == 3)
		 {
 
		   if(fam[3]==fam[4])
		     {
			 /* State 8 */
			 cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*pow(proportions[marker][distinct_alleles[0][2]],2);
			 cond_probs[1]=0;
			 cond_probs[2]=0;
			 cond_probs[3]=0;
		     }else
		       {

		         /* State 10 */
		       cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*pow(proportions[marker][distinct_alleles[0][2]],2);
		       cond_probs[1]=proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*(pow(proportions[marker][distinct_alleles[0][1]],2)+pow(proportions[marker][distinct_alleles[0][2]],2));
		       cond_probs[2]=0;
		       cond_probs[3]=proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*(proportions[marker][distinct_alleles[0][1]]+proportions[marker][distinct_alleles[0][2]]);
		       }
		 }

	       if( distinct_alleles[1][2] == 2)
		{
		  if(fam[3]==fam[4])
		    {
		      /* State 9 */
		      cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
		      cond_probs[1]=0;
		      cond_probs[2]=0;
		      cond_probs[3]=0;
		    }else
		      {
		
			if( (fam[3]==fam[5] && fam[4]==fam[6]) || (fam[3]==fam[6] && fam[4]==fam[5])) 
			{
			  /* State 12 */
			  cond_probs[0]=0;
			  cond_probs[1]=proportions[marker][distinct_alleles[0][1]]*pow(proportions[marker][distinct_alleles[0][2]],2)*proportions[marker][distinct_alleles[0][3]];
			  cond_probs[2]=0;
			  cond_probs[3]=proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
			}else
			{
			  
			  /* State 11 */
			  cond_probs[0]=2*pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
			  cond_probs[1]=2*proportions[marker][distinct_alleles[0][1]]*pow(proportions[marker][distinct_alleles[0][1]],2)*proportions[marker][distinct_alleles[0][3]];
			  cond_probs[2]=0;
			  cond_probs[3]=0;
			}
		      }
		}
			    
	       if( distinct_alleles[1][2] == 1)
		{ 
		  /* State 13 */
		  cond_probs[0]=0;
		  cond_probs[1]=proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*pow(proportions[marker][distinct_alleles[0][3]],2);
		  cond_probs[2]=0;
		  cond_probs[3]=0;
		}
	       
	       break;
	 case 2:
	   
	   if(n_a == 3)
	     {

	       /* State 14 */
	       cond_probs[0]=2*proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][1]]*pow(proportions[marker][distinct_alleles[0][3]],2);
	       cond_probs[1]=0;
	       cond_probs[2]=2*proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]];
	       cond_probs[3]=0;
	     }else
	       {
		
		 /* State 15 */
		 cond_probs[0]=proportions[marker][distinct_alleles[0][1]]*proportions[marker][distinct_alleles[0][2]]*proportions[marker][distinct_alleles[0][3]]*proportions[marker][distinct_alleles[0][4]];
		 cond_probs[1]=0;
		 cond_probs[2]=0;
		 cond_probs[3]=0;
	       }
	   
	  break;
	 }
     }

 if( par ==2)
   {
     temp=cond_probs[1];
     cond_probs[1]=cond_probs[2];
     cond_probs[2]=temp;
   }
     
    }
  return ;   

}

int sort_f(int dim,int mat[2][5])
{
  int i,j,k;
  int temp;
  
  for( i=1;i<=dim;i++)
    {
      for( j =1;j<=dim-i;j++)
	if(mat[1][j] < mat[1][j+1])
	  {
	    for(k=0;k<2;k++)
	      {
		temp = mat[k][j];
		mat[k][j]=mat[k][j+1];
		mat[k][j+1] =temp;
	      }
	  }
    }

  return 0;
}





/* ################################################# */ 

void par_cond_state_prob_f(int family[5][3], double *cond_probs)
{
 
  /*************************************************************************/
  /* this function takes the genotypes of a nuclear family, w/ both parents*/
  /* and returns the P(G_S|P_1,P_2,V_i)                                    */
  /*************************************************************************/

     double temp,vec_prob,state_prob,sum;
     int i,j,k,l,states=3;
     int sib1[2],sib2[2],father[2], mother[2],inher_vector[5],compatibles;
     int track,compat[17];

  int check=0;
  for(i=0;i<5;i++)
    cond_probs[i]=.25;

  for(i=3;i<5;i++)
    if( family[i][1]*family[i][2] > 0 )
      check++;
  if( check == 2)
    {


     for(i=1;i<3;i++)
       {
	 father[i-1] = family[1][i];
	 mother[i-1] =family[2][i];
	 sib1[i-1] = family[3][i]; 
	 sib2[i-1] = family[4][i];
       }

    for(i=1;i<5;i++)
      inher_vector[i]=0;
    vec_prob=(double)1/16;
  
    track=0;
       while(inher_vector[1] < 2)
      {
	track++;

	compatibles=0;
	for(i=1;i<3;i++)
	  {
	    for(j=1;j<3;j++)
	      {
		/*  for(k=1;k<3;k++) */
		  {
		 /*     for(l=1;l<3;l++) */
		      {
			if( (( sib1[0] == father[inher_vector[1]]) && (sib1[1] == mother[inher_vector[2]])) ||(( sib1[1] == father[inher_vector[1]]) && (sib1[0] == mother[inher_vector[2]])))
if( (( sib2[0] == father[inher_vector[3]]) && (sib2[1] == mother[inher_vector[4]])) ||(( sib2[1] == father[inher_vector[3]]) && (sib2[0] == mother[inher_vector[4]])))
				compatibles++;	
 		      }
		 /*     swap_f(sib1); */
		  }
		swap_f(mother);
	      }
	    swap_f(father);
	  }
	
	compat[track]=compatibles;
	update_inher_vec_indexes_f(inher_vector,4,1);
      }
 


/* for(i=1;i<17;i++) */
/*   cond_probs[i]=(double)compat[i]/4; */

 cond_probs[0]=(double)(compat[4]+compat[7]+compat[10]+compat[13])/16;
 cond_probs[1]=(double)(compat[2]+compat[5]+compat[12]+compat[15])/16;
 cond_probs[2]=(double)(compat[3]+compat[8]+compat[9]+compat[14])/16;
 cond_probs[3]=(double)(compat[1]+compat[6]+compat[11]+compat[16])/16;

    }

 return  ;
}



/* ################################################# */ 
/* ################################################# */ 
/* #######     Multipoint Routines    ############## */ 
/* ################################################# */ 
/* ################################################# */ 
/* int trans_mats_f(int n_locs,double locations[max_locs+1]) */
/* { */
/* /\*   This function computes the transition matrices from any            *\/ */
/* /\*   loci l to the flanking markers (low_marker[l] and low_marker[l]+1) *\/ */
/*   int i,l,j; */
/*  for(l=1;l<=n_locs;++l) */
/*    for(i=0;i<2;i++) */
/*      ext_trans_ibd_mat_f(cM_to_rec_f(map,fabs(locations[l] - marker_locations[low_marker[l]+i])),trans_mats[l][i]); */
/*  return 1; */

/* } */

int trans_mats_f(int n_locs,double locations[max_locs+1])
{
/*   This function computes the transition matrices from any            */
/*   loci l to the flanking markers (low_marker[l] and low_marker[l]+1) */
  int i,l,j;

 for(l=1;l<=n_locs;++l)
   for(i=0;i<2;i++)
     ext_trans_ibd_mat_f(cM_to_rec_f(map,fabs(locations[l] - locations[mark_ranks[low_marker[l]+i]])),trans_mats[l][i]);
 return 1;

}

double trans_inher_probs_f(int *vec1,int *vec2, double theta)
{
  int i,r;
  double prob;
  r=0;
  for(i=0;i<4;i++)
    if( vec1[i] != vec2[i])
      r++;
 
  prob = pow(theta,r)*pow(1-theta,4-r);
  return prob;
}


/* ################################################# */ 

int multi_ibd_f(char *ped_file,int n_locs,double locations[max_locs+1])
{
/*******************************************************************/
/*   this function reads the file with n families and calculates   */
/*   the number of nuclear families in the file, and also computes */
/*   multipoint IBD sharings at each loci l for each pair of affected*/ 
/*   sib-pair                                                      */
/*******************************************************************/

  int i,j,k,l,n,m,f,s1,s2,p,par;
  int family[max_markers+1][5][3];
  FILE *pedigree;

  double family_id, current_family;
  int families[max_members+1][7],family_genos[max_markers+1][max_fam_members+1][3];
  int nuclear_families[max_nuc_families+1][max_fam_members+1];
  int uninfo,members,founders,flag;
  int aff,aff_sibs;

  double fam_phenos[max_members+1];

  pedigree= fopen(ped_file ,"r");
  fscanf(pedigree,"%lf",&current_family);
  rewind(pedigree);
  founders = 0;
  members=0;
  flag = 1;

  for(p=0;p<3;p++)	
    parents[p]=0;	


  n=0;
  while (flag < 2)
    {

      if(fscanf(pedigree,"%lf",&family_id) != 1)
	{
	  family_id = -23;
	  flag++;
	}     
     
     if(family_id != current_family)
       {
	 f=split_to_nuclear_f(families,members,founders,nuclear_families);

	 for(i=1;i<=f;i++)
	   {
	     
	     par=0;
	     for(p=1;p<3;p++)
	       par+=family_genos[0][nuclear_families[i][p]][0];
	     aff_sibs=0; 
	     for(j=3;j<= nuclear_families[i][0];j++)
	       {
		 aff=0;
		 if(families[nuclear_families[i][j]][5] == 2)
		   aff=1;
		 aff_sibs +=aff*family_genos[0][nuclear_families[i][j]][0];
		 
	       }

	     if(aff_sibs>=2)
	       {
		 family[0][0][0]=(int)current_family;
		 for(p=1;p<3;p++)
		   family[0][p][0]=families[nuclear_families[i][p]][1];

		 for(p=1;p<3;p++)
		   for(m=1;m<=markers;m++)
		     for(j=1;j<3;j++)
		       family[m][p][j]=family_genos[m][nuclear_families[i][p]][j];
		 
		 for( s1=3;s1<nuclear_families[i][0];s1++)
		   if(family_genos[0][nuclear_families[i][s1]][0]*families[nuclear_families[i][s1]][5]==2)
		   {
		     family[0][3][0]=families[nuclear_families[i][s1]][1];
		     for(m=1;m<=markers;m++)
		       for(j=1;j<3;j++)
			 family[m][3][j]=family_genos[m][nuclear_families[i][s1]][j];
 
		     for( s2=s1+1;s2<=nuclear_families[i][0];s2++)
		       if(family_genos[0][nuclear_families[i][s2]][0]*families[nuclear_families[i][s2]][5]==2)
		       {
			 family[0][4][0]=families[nuclear_families[i][s2]][1];
			 n++;
			 parents[par]++;
			 family_ids[n][0]=current_family;
			 family_ids[n][1]=(double)families[nuclear_families[i][s1]][1];
			 family_ids[n][2]=(double)families[nuclear_families[i][s2]][1];

			 for(m=1;m<=markers;m++)
			   for(j=1;j<3;j++)
			     family[m][4][j]=family_genos[m][nuclear_families[i][s2]][j];
				 
			 family_multi_ibd_f(n_locs,locations,family,ibd_share[n]);		

		       }
		   }
	       }
	   }
       	 

	 founders=0;
	 members =0;
	 current_family = family_id;
       }   
 
     members++;
   
     for(i=1;i<=add_info-1;i++)
       fscanf(pedigree,"%d",&families[members][i]);
     
     if( families[members][2]== 0 && families[members][3] == 0)
       founders++;
     
     uninfo=0;
     for(i=1;i<=markers;i++)
       {
	 for(j=1;j<3;j++)
	   {
	     fscanf(pedigree,"%d",&family_genos[i][members][j]);	     
	     uninfo+=family_genos[i][members][j];
	   }
       }
     family_genos[0][members][0]=1;
     if(uninfo==0)
       family_genos[0][members][0]=0;
    }
  
  return n;
  
}

/* ################################################# */ 

int family_multi_ibd_f(int n_l,double locations[max_locs+1],int family[max_markers+1][5][3], double ibd[max_locs+1][3])
{
  /*******************************************************************/
  /*   this function takes a nuclear family with exactly two affected*/
  /*   sibs and returns the multipoint IBD sharing at each locus in  */
  /*   locations                                                     */
  /*******************************************************************/

  int i,j,k,l,m,n;
  double sum,temp,like[4];
  double lower_states[4], upper_states[4];
  double IBD[4];
  double cond_probs[4];
  double forward[max_markers +2][4],backward[max_markers +2][4];


 for(i=0;i<4;i++)
   IBD[i] = 1;
     
 forward_back_probs_f(family, forward, backward);

 for(l=1;l<=n_l;++l)
   {

     vec_mat_prod_f(4,forward[low_marker[l]],trans_mats[l][0],lower_states,0);
     vec_mat_prod_f(4,backward[low_marker[l]+1],trans_mats[l][1],upper_states,0);
     vec_elem_prod_f(4,lower_states,upper_states,like,0);
     sum = vec_prod_f(4,like,IBD,0);

     ibd[l][0] = like[0]/sum;
     ibd[l][1] = (like[1]+like[2])/sum;
     ibd[l][2] = like[3]/sum;

   }
 return 0;

}


/* ################################################# */ 

void ext_trans_ibd_mat_f(double theta,double trans_mat[4][4])
{
/*   This function computes the extended IBD transition matrix b/  */
/*   two  loci with rec fraction theta                             */
  int i,j;
  trans_mat[0][0]=pow(pow(theta,2)+ pow(1-theta,2),2);
  trans_mat[0][1]=2*theta*(1-theta)*(pow(theta,2)+ pow(1-theta,2));
  trans_mat[0][2]=trans_mat[0][1];
  trans_mat[0][3]=4*(pow(theta,2)*pow(1-theta,2));

  trans_mat[1][1]= trans_mat[0][0];
  trans_mat[1][2]= trans_mat[0][3];
  trans_mat[1][3]= trans_mat[0][1];

  trans_mat[2][2]= trans_mat[0][0];
  trans_mat[2][3]= trans_mat[0][1];

  trans_mat[3][3]= trans_mat[0][0];

  for(i=0;i<4;i++)
    for(j=i+1;j<4;j++)
      trans_mat[j][i] = trans_mat[i][j];


  return;
}




/* ################################################# */ 

int forward_back_probs_f(int family[max_markers][5][3], double forward[max_markers +2][4],double  backward[max_markers +2][4])
{

  /*************************************************************************/
  /* this function takes the genotypes of a nuclear family, and returns the*/
  /* P(G1,G2,...,Gt|Vt=V_i) and P(GM,GM-1,...,Gt|Vt=V_i)                   */
  /*************************************************************************/
  int i,j,k,l,m,t,par;
  double sum,IBD[4];
  double cond_probs[max_markers +1][4];
  double lower_states[4], upper_states[4];
  for(i=0;i<4;i++)
    IBD[i] = .25;
  
  /* Conditional probabilities of the Family Genotypes, given IBD state */
  for(i=1;i<=markers;++i)
    {
      for(k=0;k<4;k++)
	cond_probs[i][k]=1;
      l=0;
      for( k=3;k<5;k++)
	if(family[i][k][1]*family[i][k][2] >0)
	  l++;
      if(l>1)
	{
	  par=0;
	  for( k=1;k<3;k++)
	    if( family[i][k][1]*family[i][k][2]!=0)
	      par++;
	  switch(par)
	    {
	    case 0:
	      /*No Parents */
	      sib_cond_state_prob_f(i,family[i], cond_probs[i]);
	      break;
	    case 1:
	      /*One Parent */
	      one_cond_state_prob_f(i,family[i], cond_probs[i]);
	      break;
	    case 2:
	      /*Two Parents */
	      par_cond_state_prob_f(family[i],cond_probs[i]);
	      break;
	    }
	}
      sum = 4*vec_prod_f(4,cond_probs[i],IBD,0);
      if( sum == 0)
	{
	  for(j=0;j<4;j++)
	    cond_probs[i][j] = .25;
	  printf("<< Warning>> Mendelian Problem\n"); 
	  printf("Family:\t%7d\n",family[0][0][0]);
	  printf("Members:");
	  for(j=1;j<5;j++)
	    printf("%7d ",family[0][j][0]);
	  printf("\n");
	  printf("Marker:\t%7d\n",i);
	}

    }
  /* Initiating the Backward and Forward Vectors */
  
  for(i=0;i<=markers+1;i++)
    for(j=0;j<4;j++)
      {
	forward[i][j]=1;
	backward[i][j]=1;
      }
  
      for( i=1;i<=markers;i++)
	{
	  
	  vec_mat_prod_f(4,forward[i-1],trans_mats[mark_ranks[i-1]][1],forward[i],0);
	  vec_elem_prod_f(4,forward[i],cond_probs[i],forward[i],0);


	  sum=0;
	  for(j=0;j<4;j++)
	    sum+= forward[i][j];
	     
	  for(j=0;j<4;j++) 
	    forward[i][j] /=sum;

	}

      /* Backward Probabilities */
      
      for( i=markers;i>=1;i--)
	{
	      
	  vec_mat_prod_f(4,backward[i+1],trans_mats[mark_ranks[i]][1],backward[i],0);
	  vec_elem_prod_f(4,backward[i],cond_probs[i],backward[i],0);

	  sum=0;
	  for(j=0;j<4;j++)
	    sum+= backward[i][j];
	     
	  for(j=0;j<4;j++) 
	    backward[i][j] /=sum;

	}



  return 0;

}


/* ################################################# */ 

void cdf_f(int n,double *pdf, double *cdf)
{
  int j;

  cdf[0] = pdf[0] ;
  for(j=1;j<=n;j++)
    cdf[j]=cdf[j-1]+pdf[j];
  return;
}

/* ################################################# */ 

void update_inher_vec_indexes_f(int *indexes,int n, int max_index)
{
  int i;

  indexes[n]++;
  for( i=n-1;i>0;i--)
    if(indexes[i+1] > max_index)
      {
	indexes[i+1]=0;
	indexes[i]++;
	  }
  return;
}

/* ################################################# */ 

void update_state_indexes_f(int *indexes,int n,int max_indexes)
{
  int i;
  
  indexes[1]++;
  for( i=2;i<=n;i++)
    if(indexes[i-1] > max_indexes)
      {
	indexes[i-1]=1;
	indexes[i]++;
      }
  return;
}

/* ################################################# */ 

void update_vec_indexes_f(int *indexes,int n,int *max_indexes)
{
  int i;
  
  indexes[1]++;
  for( i=2;i<=n;i++)
    if(indexes[i-1] > max_indexes[i-1])
      {
	indexes[i-1]=0;
	indexes[i]++;
      }
  return;
}


/* ################################################# */ 
/* ################################################# */ 
/* exact routines mean IBD*/
/* ################################################# */ 
/* ################################################# */ 


int cond_prob_parents_f(int marker, double probs[12][4])
{
/* ######################################################## */
 /* This Function Calculates the Two Point distribution at   */
/* the marker locus assumming info on both parents          */ 
/* ######################################################## */

  int i,j,k,l;
  double sum[6];

/*#########################################################*/
/*#########################################################*/

  for(i=1;i<=11;i++)
    for(j=0;j<4;j++)
      probs[i][j]=0;
  
  for(i=0;i<6;i++)
    sum[i]=0;
  
  /*1) sum(p_i)^4 */
  
  for(i=1;i<=alleles[marker];i++)
      sum[1]+= pow(proportions[marker][i],4);

  /*2) sum(p_i)^3(p_j) */
  
  for(i=1;i<=alleles[marker];i++)
    for(j=1;j<=alleles[marker];j++)
      if(i != j)
	sum[2] += pow(proportions[marker][i],3)*pow(proportions[marker][j],1);
  
  
  /*3) sum(p_i)^2(p_j)^2 */
  
  for(i=1;i<=alleles[marker];i++)
    for(j=i+1;j<=alleles[marker];j++)
      sum[3] += pow(proportions[marker][i],2)*pow(proportions[marker][j],2);
  
  
  /*4) sum(p_i)^2(p_j)(p_k) */
  
  for(i=1;i<=alleles[marker];i++)
    for(j=1;j<=alleles[marker];j++)
      if(i != j)
	for(k=j+1;k<=alleles[marker];k++)
	  if(i != k)
	    sum[4] += pow(proportions[marker][i],2)*pow(proportions[marker][j],1)*pow(proportions[marker][k],1);
  
  /*5) sum(p_i)(p_j)(p_k)(p_l) */
  
  for(i=1;i<=alleles[marker];i++)
    for(j=i+1;j<=alleles[marker];j++)
      for(k=j+1;k<=alleles[marker];k++)
	for(l=k+1;l<=alleles[marker];l++)
	  sum[5]+= proportions[marker][i] * proportions[marker][j] * proportions[marker][k] * proportions[marker][l];
  
    
  /* Class 1*/
  
  probs[1][2]= 2*(sum[2]+sum[4]);
  probs[1][3]= probs[1][2];

  /* Class 2*/
  
  probs[2][1]= probs[1][2];
  probs[2][3]= probs[1][2];

  /* Class 3*/
  
  probs[3][1]= 4*sum[3];
  probs[3][2]= probs[3][1];

  /* Class 4*/
  
  probs[4][0]= 2*sum[3];
  probs[4][3]= probs[4][0];

  /* Class 5*/

  for(i=0;i<4;i++)
    probs[5][i]= sum[1]+ 2*sum[3];

   /* Class 6*/
  
  probs[6][0]= 2*(sum[2]+sum[4]);
  probs[6][2]= probs[6][0];

   /* Class 7*/
  
  probs[7][0]= probs[6][0];
  probs[7][1]= probs[6][0];

   /* Class 8*/
  
  probs[8][0]= 2*sum[3] + 8*sum[4]+ 24*sum[5];
 
   /* Class 9*/
  
  probs[9][3]= probs[8][0];
 
   /* Class 10*/
  
  probs[10][2]= 8*sum[4]+ 24*sum[5] ;

  /* Class 11*/
  
  probs[11][1]= probs[10][2];
   
 return 0;
}



/* ################################################# */ 
/* #########################################  */ 
/* Routines for computing multi IBD sharing*/
/* #########################################  */ 

int ibd_share_f(int family[max_markers][5][3],double ibd_share[max_locs][4])
{

  int i,j,k,l,m,t,par;
  double IBD[4];

  double forward_prob[max_markers +2][4], backward_prob[max_markers +2][4];
  double cond_probs[max_markers +1][4];
  double lower_states[4], upper_states[4];

  double stat;
  double sum;
 /* IBD Variables*/


  for(l=0;l<= n_locs;l++)
    for(j=0;j<4;j++)
      ibd_share[l][j]=0;

    forward_back_probs_f(family, forward_prob,backward_prob);

    for(l=1;l<=n_locs;l++)
      {
	vec_mat_prod_f(4,forward_prob[low_marker[l]],trans_mats[l][0],lower_states,0);
	vec_mat_prod_f(4,backward_prob[low_marker[l]+1],trans_mats[l][1],upper_states,0);
	     
	      	      
	sum=0;
	for(j=0;j<4;j++)
	  {
	    ibd_share[l][j]=lower_states[j]*upper_states[j];
	    sum+=ibd_share[l][j];
	  }
	for(j=0;j<4;j++)
	  {
	    ibd_share[l][j]/=sum;
	  }
      }

  return 0;

}


/* #########################################  */ 
/* Creating Familial Genotypes*/
/* #########################################  */ 

void inher_mat_f(double distance,double inher_mat[17][17])
{
  int i,j,k,l,c,m,diff;
  double temp,theta;



  c=1;
  for( i=0;i<2;i++)
    for(j=0;j<2;j++)
      for(k=0;k<2;k++)
	for(l=0;l<2;l++)
	  {
	    inher_vectors[c][1]=i;
	    inher_vectors[c][2]=j;
	    inher_vectors[c][3]=k;
	    inher_vectors[c][4]=l;
	    c++;
	  }
  
  
  theta =  cM_to_rec_f(map,distance);
  for(j=1;j<17;j++)
    for(k=0;k<17;k++)
      {
	if(k*j == 0)
	  inher_mat[j][k]=0;
	if(k*j > 0)
	  {
	    diff=0;
	    for(l=1;l<5;l++)
	      if( abs(inher_vectors[j][l]-inher_vectors[k][l])==1)
		diff++;
	    inher_mat[j][k]= pow(theta,diff)*pow(1-theta,4-diff);
	  }
      }
  
  
 
	 return;
       
}

/* ################################################# */ 

  void trans_info_f()
    {
      int i,j,k,l,c,m;
      double d1,d2;
      c=1;
      for( i=0;i<2;i++)
	for(j=0;j<2;j++)
	  for(k=0;k<2;k++)
	    for(l=0;l<2;l++)
	      {
		inher_vectors[c][1]=i;
		inher_vectors[c][2]=j;
		inher_vectors[c][3]=k;
		inher_vectors[c][4]=l;
		c++;
	      }
      tot_ibd_vecs[0] = 4;
      tot_ibd_vecs[1] = 8;
      tot_ibd_vecs[2] = 4;
      
      
     
      ibd_vecs[0][1] = 4;
      ibd_vecs[0][2] = 7;
      ibd_vecs[0][3] = 10;
      ibd_vecs[0][4] = 13;
     
      ibd_vecs[1][1] = 2;
      ibd_vecs[1][2] = 3;
      ibd_vecs[1][3] = 5;
      ibd_vecs[1][4] = 8;
      ibd_vecs[1][5] = 9;
      ibd_vecs[1][6] = 12;
      ibd_vecs[1][7] = 14;
      ibd_vecs[1][8] = 15;
      
      ibd_vecs[2][1] = 1;
      ibd_vecs[2][2] = 6;
      ibd_vecs[2][3] = 11;
      ibd_vecs[2][4] = 16;


     for(i=1;i< markers;++i)
  	 inher_mat_f(distances[i],trans_mark_inher_mat[i]);
     for(i=1;i<= markers;++i)
       {
	 proportions[i][0]=0;
	 cdf_f(alleles[i],proportions[i], cdf_proportions[i]);
       }

     return; 
    }



/* ################################################# */ 
/* ################################################# */ 

int nuclear_family_marker_f(int marker, double *inher_probs)
{
  int i,j,k,v,c;
  int inher_vec[5];


  v = random_int_f(inher_probs);

  for(j=1;j<5;j++)
    inher_vec[j] = inher_vectors[v][j] +1 ;
  for(i=1;i<3;i++)
    for(j=1;j<3;j++)
	nuc_family[marker][i][j] = random_int_f(cdf_proportions[marker]);

  c = 1;
  for(i=3;i<5;i++)
    for(j=1;j<3;j++)
      {
	nuc_family[marker][i][j] = nuc_family[marker][j][inher_vec[c]];
	c++;
      }
  
	 return v;
}

/* ################################################# */ 

int nuclear_family_f(double *t_cdf_ibd, double disease_loc)
{

  int j,i,k,closest,vec, ibd, U, L;
  int vecs[markers+2];
  double cdf[17];

  closest=0;
  while(closest<markers && locations[mark_ranks[closest+1]] <= disease_loc)
    closest++;
  /* Sampling the IBD state and Inher Vec at the trait locus*/
  
  ibd=random_int_f(t_cdf_ibd);
  vec = ibd_vecs[ibd][unif_int_f(tot_ibd_vecs[ibd])];
  L = closest;
  U = closest+1;
  /* Sampling the Marker state of the flanking markers*/
 
  /* Flanking Lower */
  if( L > 0)
    {
      cdf_f(16,flank_trans_inher_mat[1][vec],cdf);
      vecs[L] = nuclear_family_marker_f(L,cdf);
    }else
      {
	cdf_f(16,flank_trans_inher_mat[1][vec],cdf);
	vecs[L]=random_int_f(cdf);
       }

  /* Flanking Upper */
 if(U <= markers)
   { 
     cdf_f(16,flank_trans_inher_mat[2][vec],cdf);
     vecs[U] = nuclear_family_marker_f(U,cdf);
   }else
     {
       cdf_f(16,flank_trans_inher_mat[2][vec],cdf);
       vecs[U]=random_int_f(cdf);
     }

  /* Sampling the Marker state of the rest markers*/

  /* Lower Markers*/
  for(j=L-1;j>0;j--)
    {
      cdf_f(16,trans_mark_inher_mat[j][vecs[j+1]],cdf);
      vecs[j] = nuclear_family_marker_f(j,cdf);
    }
  

  /* Upper Markers*/
  
  for(j=U+1;j<= markers;j++)
    {	  
      cdf_f(16,trans_mark_inher_mat[j-1][vecs[j-1]],cdf);
      vecs[j] = nuclear_family_marker_f(j,cdf);
    }
 

  return 0;
}


/* ################################################# */ 

int  random_int_f(double *cdf)
{

  double u;
  int index;

  index=0;
   u = rans();
   while(u >= cdf[index])
   index=index+1;
  
   return index;

  
}



int  unif_int_f(int n)
{
   return (ceil(rans()*n));
  
}

