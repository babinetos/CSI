
/* ################################################# */ 
/* General functions: Reading marker info, spitting into nuclear families, etc */
/* ################################################# */ 

int read_marker_info_f(char *loc_file);
int locations_f(int analysis,int mode,int points,int inter_locs,double incre,double offend,double *locations);
int split_to_nuclear_f(int family_det[max_members+1][7], int members,int founders,int nuclear_family[max_nuc_families+1][max_fam_members+1]);
int read_ped_f(char *ped_file);


double cM_to_rec_f(int func,double cM);
double rec_to_cM_f(int func,double theta);

void vec_elem_prod_f(int m, double *A,double *B, double *C, int s);
void vec_mat_prod_f(int m, double *A,double B[m][m], double *C, int s);
double vec_prod_f(int m, double *A,double *B, int s);
void standardize_f(int m, double *unstandard, double *standard, int start);

void swap_f(int *person);


/* Two point functions  */
int joint_prob_rel_f(double ibd[3],int alleles, double proportions[],double geno_prob[8]);
int new_cond_no_parents_f (int alleles, double proportions[], double cond_exp[2][4]);
int new_cond_one_parent_f(int alleles, double proportions[],double expect[2][4]);
int new_cond_parents_f(int alleles, double proportions[],double cond_expect[2][4]);
int two_ibd_f(char *ped_file);
int family_two_ibd_f(int nuc_family[max_markers+1][5][3], double ibd[max_locs+1][3]);
void par_state_prob_f(int marker);
void sib_cond_state_prob_f(int marker,int family[5][3], double *cond_probs);
void one_cond_state_prob_f(int marker,int family[5][3], double *cond_probs);
void par_cond_state_prob_f(int family[5][3], double *cond_probs);

int sort_f(int dim,int mat[2][5]); /* needed in the one parent functiion*/

/* ################################################# */ 
/* Multipoint Functions - The ibd functions need also the twopoint above */
/* ################################################# */ 

int trans_mats_f(int n_locs,double locations[max_locs+1]);

void inher_mat_f(double distance,double inher_mat[17][17]);
/* this function gives matrix with transition probabilities of two loci of distance d*/

int multi_ibd_f(char *ped_file,int n_locs,double locations[max_locs+1]);

int family_multi_ibd_f(int n_l,double locations[max_locs+1],int nuc_family[max_markers+1][5][3], double ibd[max_locs+1][3]);


void ext_trans_ibd_mat_f(double theta,double trans_mat[4][4]);

int forward_back_probs_f(int family[max_markers][5][3], double forward_prob[max_markers +2][4],double  backward_prob[max_markers +2][4]);

void cdf_f(int n,double *pdf, double *cdf);
void update_inher_vec_indexes_f(int *indexes,int n, int max_index);
/* updating vector of indexes (starts from 0) */
void update_vec_indexes_f(int *indexes,int n,int *max_indexes); 
void update_state_indexes_f(int *indexes,int n,int max_indexes); 

/* ########################### */ 
/* exact routines mean IBD*/
/* Exact computations only in the case */
/* of parental info */
/* ########################### */ 
int cond_prob_parents_f(int marker, double probs[12][4]);

int multi_stats_at_f(int parents,double cond_expect[max_locs+1][2][4]);
int multi_stats_fixed_f(int parents, double distance0, double cond_expect[max_locs+1][2][4]);
int multi_stats_mark_f(int parents, double cond_expect[2][max_locs+1][2][4]);
void new_sim_multi_mark_means_f(int pars,double *t_cdf, int reps,double  stats[max_locs][2]);

/* #########################################  */ 
/* Simulated computations multi IBD sharing*/
/* #########################################  */ 

double mean_loc_ibd_share_f(int nuc_family[max_markers][5][3],int l);
/* returns the multipoint mean IBD sharing at locus loc of marker interval (m,m+1) */ 

void sim_multi_at_means_f(int pars,double *t_cdf, int reps,double  stats[max_locs][2]);
/* estimates mean and var of all loci given cdf of trait, and computing stat at locus of trait */
void sim_multi_mark_means_f(int pars,int side,double *t_cdf, int reps,double  stats[max_locs][2]);
/* estimates mean and var of all loci given cdf of trait, and computing stat at lower flanking mark (side = 0) or upper (side = 1) */
void sim_multi_fixed_means_f(int pars,double disease_loc, double *t_cdf, int reps,double  stats[max_locs][2]);

int ibd_share_f(int nuc_family[max_markers][5][3],double ibd_share[max_locs][4]);

/* #########################################  */ 
/* Creating Familial Genotypes*/
/* #########################################  */ 

void inher_mat_f(double distance,double inher_mat[17][17]);
/* this function gives matrix with transition probabilities of two loci of distance d*/

void trans_info_f();
/* computes transition probabilities of inher vecs */

int nuclear_family_marker_f(int marker, double *inher_probs);
/* creates genotype for a marker for a nuc family given the probability of the inher vectors */

int nuclear_family_f(double *t_cdf_ibd, double disease_loc);
/* creates genotype for a nuc family given the probability of the inher vectors */


/* Distributions */ 

int  unif_int_f(int n);
/* discrete uniform 1-n */
int  random_int_f(double *cdf);
/* Discrete on 0-n, with given cdf */ 



/* #########################################  */ 
/* Likelihood Functions*/
/* #########################################  */ 

double max_fixed_log_likelihood_f(int ite,int loc,double tol,double *z);
double alt_IBD_log_likelihood_f(int nvar,double *parameters);
double refined_max_fixed_log_likelihood_f(int ite,double tau,double tol,double *z);
int max_log_likelihood_f(double *estimates,double ratios[max_locs+1][5]);
