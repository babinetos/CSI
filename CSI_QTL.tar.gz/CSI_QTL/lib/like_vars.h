typedef struct PED {
  double id;
  int npeople; /* Total number in the pedigree. */
  int *p_ids;
  int *f_ids;
  int *m_ids;
  int *sexes;
  int *d_statuses;
  double *phenos;
  int ***genos;
  int ncovars;
  DMATRIX covariates;
} PED_t;


typedef struct MAP {
  int nm; /* Total number in the pedigree. */
  double *locs;
  double *dists; /* distance b/ marker i and i-1 */
  double *recfrc;
  int *alleles;
  double **ps;
  char **names;
} MAP_t;

#define PI 3.14159265
#define MAXLEN 100000
#define EPS 1e-6

double alpha=.05;
int map=0,npeds,add_info=5;
int multi_fams=0;
PED_t *peds;           /* pedigree information */
MAP_t MAP;           /* marker information */
DMATRIX **V_MATS;     /* Covar matrices V_i such that Sigma = sum{s_i^2*V_i} */
/* DMATRIX Null_CHOL;   /\* Cholesky Decomposition for MC covar matrix *\/ */
int nsigmas;          /* Number of variance components */
/* double *sigma_hat,*beta_hat;  /\* Estimates of variance components *\/ */
double TOL;           /* Criterion max{|s_i|,|b_j|} < TOL */
int maxite;
DMATRIX *GI_mats;
DMATRIX VS,VSI;       /*Matrices needed in the Q_s*/
double DET;
/* double *XB; */
double ln2pi;

double **slims,**blims;
int *spoints,*bpoints;

DMATRIX TEMP_MAT;

int screen=0,sim=0;

#define max_alleles 2
#define max_markers 4000
#define max_members 300
double p_mis;
