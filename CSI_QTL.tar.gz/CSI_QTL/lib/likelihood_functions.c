#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "vars.h"
#include "math_functions.h"
#include "ibd_functions.h"
#include "rans.h"
#include "likelihood_functions.h"
