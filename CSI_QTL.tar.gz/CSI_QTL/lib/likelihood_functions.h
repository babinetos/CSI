double b_grid_loglike_f(double *sigmas, double **lims,int *points, double *bmaxs);

double gsl_logL_f(const gsl_vector *v, void *params);
void gsl_grad_logL_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_logL_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);

double log_L_beta_sigma_f(double *betas,double *sigmas);
double log_L_f(double *x, double *pars);
int grad_L_f(double *x, double *grad, double *pars);
int VAR_MAT_f(int nsigmas, PED_t ped, DMATRIX *V);
int DOM_VAR_MAT_f(PED_t ped, int *orders, DMATRIX V);
int ADD_VAR_MAT_f(PED_t ped, int *orders, DMATRIX V);
int unrelated_founders_f(int person,int nf, int *founders, PED_t ped,int *orders, int *unrel_found);
int ancestors_f(int person, PED_t ped,int *orders, int *ancest);



