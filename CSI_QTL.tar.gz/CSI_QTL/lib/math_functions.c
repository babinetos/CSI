/* cc -c  math_functions.c */
/* ar ruv math_functions.a math_functions.o */
/* ######################################################## */
/*             This file contains math functions            */
/* ######################################################## */

#include <math.h>
#include <string.h>
#include "math_functions.h"
int word_cnt(char *s)
{
  int cnt=0;
  while(*s !='\0'){
    while(isspace(*s))
      ++s;
    if(*s !='\0'){
      ++cnt;
      while( !isspace(*s) && *s !='\0')
	     ++s;
    }
  }  
       return cnt;
}

int mod_f(int n,int base)
{
  int k;
  k=n - (n/base)*base;
  return k;
} 



double  min(double  one,double  two)
{
  if (one > two)
    return two;
   else
    return one ;
 
}


double  max(double  one,double  two)
{
  if (one < two)
    return two;
   else
    return one ;
 
}

// replicates Sgn as in visual basic, the signum of a real number
double sgn(double a)
{
if (a>0)
        return 1.;
else if (a<0)
        return -1.;
else
        return 0.;
}


int factorial_f(int n)
{
if( n == 0 || n ==1)
return 1;
else 
  return (n*factorial_f(n-1));
}

int combinations_f(int n,int k)
{
  if(n>=k)
    return factorial_f(n)/(factorial_f(k)*factorial_f(n-k));
  else
    return 0;
}


/* ################################################# */ 
/* ################################################# */ 
/* vectors */
/* ################################################# */ 
/* ################################################# */ 





void Vec3_product(int dim,double A[][3], double B[3],double D[],int start)
{
  /* Multiplies A*B and stores it in C*/

  int i,j;
  double C[10];

  for(i=0;i<dim;i++)
    {
      C[i] = 0;
      for(j=0;j<3;j++)
	C[i] += A[i][j]*B[j];
    }

 for(i=0;i<dim;i++)
   D[i] =  C[i];

 return;

 }


void Mat_Vec3_product(double A[3][3], double B[3],double D[3])
{
  /* Multiplies A*B and stores it in C*/

  int i,j,m1,m2,start;
  double C[3];
  start=0;
  m1=3;
  m2=3;
      for(i=start;i<m1;i++)
	{
	  C[i] = 0;
	  for(j=start;j<m2;j++)
	    C[i] += A[i][j]*B[j];
	}
      
      for(i=start;i<m1;i++)
	D[i] =  C[i];
return;
}


void Vec_Mat3_product(double A[3], double B[3][3],double D[3])
{
  /* Multiplies A*B and stores it in C*/

  int i,j,m1,m2,start;
  double C[3];
  start=0;
  m1=3;
  m2=3;

for(i=start;i<m2;i++)
{
  C[i] = 0;
  for(j=start;j<m2;j++)
    C[i] += A[j]*B[j][i];
}
      
 for(i=start;i<m2;i++)
   D[i] =  C[i];

 return;

 }

void Mat3_product(double A[3][3], double B[3][3],double D[3][3])
{
  /* Multiplies A*B and stores it in C*/

  int i,j,k,m1,m2,n1,n2,start;
  double C[3][3];
  start=0;
  m1=3;
  m2=3;
  n1=3;
  n2=3;


     for(i=start;i<m1;i++)
	{
	  for(j=start;j<n2;j++)
	    {
	      
	      C[i][j] = 0;
	      
	      for(k=start;k<m2;k++)
		C[i][j] += A[i][k]*B[k][j];
	    }
	}
      
      for(i=start;i<m2;i++)
	for(j=start;j<n2;j++)
	  D[i][j] =  C[i][j];
return;
 }




void Trans_Mat3(double A[3][3], double B[3][3])
{
  /* Multiplies A*B and stores it in C*/

  int i,j,k,m1,m2,n1,n2,start;
  double C[3][3];
  start=0;
  m1=3;
  m2=3;

     for(i=start;i<m1;i++)
	{
	  for(j=start;j<m2;j++)
	    {
	      C[i][j] = A[j][i];
	    }
	}
      
      for(i=start;i<m1;i++)
	for(j=start;j<m2;j++)
	  B[i][j] =  C[i][j];
return;
 }


double Vec_product(int dim,double A[], double B[],int start)
{
  /* Multiplies A*B and stores it in C*/

  int i,j;
  double C;

  C = 0;
  for(j=start;j<=dim;j++)
    C+= A[j]*B[j];
 return C;

 }

int mat_invert_f(int dim,int s, double matrix[dim+s][dim+s],double inv_matrix[dim+s][dim+s])
{
  int i,j,l;
  double c;
  for(i=0+s;i<dim+s;i++)
    for(j=0+s;j<dim+s;j++)
	inv_matrix[i][j]=0;
  for(i=0+s;i<dim+s;i++)
    inv_matrix[i][i]=1;

  for(i=0+s;i<dim+s;i++)
   {
     c=matrix[i][i];
     for(j=0+s;j<dim+s;j++)
       {
	 matrix[i][j] = matrix[i][j]/c;
	 inv_matrix[i][j] = inv_matrix[i][j]/c;
       }
     for(j=0+s;j<dim+s;j++)
       {
	 c=matrix[j][i];
	 if( j !=i)
	   for(l=0;l<dim+s;l++)
	     {
	       matrix[j][l] = matrix[j][l] - c*matrix[i][l];
	       inv_matrix[j][l] = inv_matrix[j][l] - c*inv_matrix[i][l];
    
	     }
       }
   }

 return 0;
}

