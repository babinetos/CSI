#define max_dim 10


double  min(double  one,double  two);
double  max(double  one,double  two);
double sgn(double a);
int factorial_f(int n);
int combinations_f(int n,int k);
int word_cnt(char *s);
int mod_f(int n,int base);


/* Matrix-vector operations */

void Vec3_product(int dim,double A[][3], double B[3],double D[],int start);
void Mat_Vec3_product(double A[3][3], double B[3],double D[3]);
void Vec_Mat3_product(double A[3], double B[3][3],double D[3]);
void Mat3_product(double A[3][3], double B[3][3],double D[3][3]);
void Trans_Mat3(double A[3][3], double B[3][3]);
double Vec_product(int dim,double A[], double B[],int start);
int mat_invert_f(int dim,int s, double matrix[dim+s][dim+s],double inv_matrix[dim+s][dim+s]);

