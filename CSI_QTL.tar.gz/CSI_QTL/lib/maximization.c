#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "vec_mat.h"
#include "files.h"
#include "cblas.h"

#define EPS 1e-6


int norm_test_grad(int n,double *x,double TOL,int s)
{
  int i;
  double D=0;
  for(i=s;i<n+s;i++)
      D+=pow(x[i],2);

  if(D <=TOL)
    { 
      return 1;
    }else
      return 0;
}

/*################################################################*/

int norm_test_vectors(int n,double *x,double *y,double TOL,int s)
{
  int i;
  double D=0;
  for(i=s;i<n+s;i++)
      D+=pow(x[i]-y[i],2);

  if(D <=TOL)
    { 
      return 1;
    }else
      return 0;
}

/*################################################################*/
/*################################################################*/
/*################################################################*/
/*################################################################*/



int df_min_f(int n_var,double (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad, double *pars),int maxite,double *x, double *grad, DMATRIX H,double *fval, int fval_index, double *pars)
{
  /* Minimizes a function funct given the gradient function dfunct.
     It returns the maximizing point (x), the value of the function f,
     the gradient, and an estimate of the Hessian matrix */
 
  int i,j,status,iter=0,flag=0;
  double x_old[n_var],grad_old[n_var];
  double u,scale=.001;
  (*df)(x,grad,pars);
  cblas_dcopy(n_var,x,1,x_old,1);
  cblas_dcopy(n_var,grad,1,grad_old,1);

  status=0;
  do
    {
      iter++;
     if( iter > 30 )
	scale=1;
      df_BFGS_minimization_iteration_f(n_var,(*df),x,grad,H,scale,pars);
      status = norm_test_grad(n_var,grad,EPS,0);
      if (status==1)
	break;
      cblas_dcopy(n_var,x,1,x_old,1);
      cblas_dcopy(n_var,grad,1,grad_old,1);
    }
  while (status == 0 && iter < maxite);

  if(fval_index==1)
    *fval=(*f)(x,pars);
  return status;
}


/*################################################################*/


int df_BFGS_minimization_iteration_f(int n_var,int (*df)(double *vars,double *grad,double *pars),double *x,double *grad,DMATRIX H,double scale, double *pars)
{
  int i;
  double x_new[n_var],grad_new[n_var],g[n_var];

  cblas_dcopy(n_var,x,1,x_new,1);
  cblas_dsymv(CblasRowMajor,CblasLower,n_var,-scale,H.arr,n_var,grad,1,1.0,x_new,1);

  (*df)(x_new,grad_new,pars);

  update_hessian_f(n_var,H,grad,grad_new,x,x_new,H);

  cblas_dcopy(n_var,x_new,1,x,1);
  cblas_dcopy(n_var,grad_new,1,grad,1);

  return 1;
}

/*################################################################*/


int tol_fdf_min_f(int n_var,double (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad, double *pars),int maxite,double *x, double *grad, DMATRIX H,double *fval, int fval_index, double TOL, double *pars)
{
  /* Minimizes a function funct given the gradient function dfunct.
     It returns the maximizing point (x), the value of the function f,
     the gradient, and an estimate of the Hessian matrix */
 
  int i,j,status,iter=0,flag=0;
  double x_old[n_var],grad_old[n_var];
  double u,scale=.01;

  (*df)(x,grad,pars);
  cblas_dcopy(n_var,x,1,x_old,1);
  cblas_dcopy(n_var,grad,1,grad_old,1);
  status=0;
  do
    {
      iter++;
      fdf_BFGS_minimization_iteration_f(n_var,(*f),(*df),x,grad,H,pars);
      status = norm_test_grad(n_var,grad,TOL,0);
      if (status==1)
	break;
      cblas_dcopy(n_var,x,1,x_old,1);
      cblas_dcopy(n_var,grad,1,grad_old,1);
    }
  while (status == 0 && iter < maxite);

  if(fval_index==1)
    *fval=(*f)(x,pars);
  return status;
}

/*################################################################*/


double min_a_line_f(int nvar,double alim,double (*funct)(double *vars, double *pars), double *x1,double *x2,double *new_x,double *pars)
{
  double a,y[nvar],lims[2],step,mina=0,f,minf=1e10;
  int i,j,np=10;
  lims[0]=.01;
  lims[1]=alim;
  double eps=5e-5;
  while( fabs(lims[1]-lims[0])>1e-4)
    {
      step=(lims[1]-lims[0])/np;
   
      for(i=0;i<=np;i++)
	{
	  a=i*step+lims[0];
	  cblas_dcopy(nvar,x1,1,y,1);
	  cblas_daxpy(nvar,a,x2,1,y,1);
	  f=(*funct)(y,pars);
	  if(f<minf)
	    {
	      minf=f;
	      mina=a;
	      cblas_dcopy(nvar,y,1,new_x,1);
	    }
	}
      lims[0]=mina-step;
      lims[1]=mina+step;
      if(lims[0]<eps)
	lims[0]=eps;
      if(lims[0]>alim)
	lims[0]=alim;
      if(lims[1]>alim)
	lims[1]=alim;
      if(lims[1]<eps)
	lims[1]=eps;
    }
  return mina;
}


/*################################################################*/

int update_hessian_f(int n_var,DMATRIX H1,double *grad1,double *grad2,double *x1,double *x2,DMATRIX H2)
{
  int i,j;
  double d1,d2;
  double c[n_var],u[n_var];
  double EPS1=1.0e-5;
  cblas_daxpy(n_var,-1.0,x2,1,x1,1);
  cblas_daxpy(n_var,-1.0,grad2,1,grad1,1);
  d1=cblas_ddot(n_var,x1,1,grad1,1);

  if(fabs(d1)> EPS1)
    {
      cblas_dsymv(CblasRowMajor,CblasLower,n_var,1.0,H1.arr,H1.cols,grad1,1,0,c,1);
      d2=cblas_ddot(n_var,c,1,grad1,1);
      if(fabs(d2)> EPS1)
	{
      for(i=0;i<n_var;i++)
	u[i]=0;
      cblas_daxpy(n_var,1.0/d1,x1,1,u,1);
      cblas_daxpy(n_var,-1.0/d2,c,1,u,1);

      for(i=0;i<n_var;i++)
	{
	  H2.mat[i][i]=H1.mat[i][i]+x1[i]*x1[i]/d1-c[i]*c[i]/d2+d2*u[i]*u[i];
	  for(j=0;j<i;j++)
	    H2.mat[i][j]= H2.mat[j][i]=H1.mat[i][j]+x1[i]*x1[j]/d1-c[i]*c[j]/d2+d2*u[i]*u[j];
	}
	}
    }
    return 1;
}



int fdf_BFGS_minimization_iteration_f(int n_var,double (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad,double *pars),double *x,double *grad,DMATRIX H,double *pars)
{
  int i;
  double a,x_new[n_var],grad_new[n_var],g[n_var];
  double temp[n_var];
  cblas_dsymv(CblasRowMajor,CblasLower,n_var,-1.0,H.arr,H.cols,grad,1,0.0,temp,1);
  a=min_a_line_f(n_var,1,(*f),x,temp,x_new,pars);
  (*df)(x_new,grad_new,pars);
  update_hessian_f(n_var,H,grad,grad_new,x,x_new,H);

  cblas_dcopy(n_var,x_new,1,x,1);
  cblas_dcopy(n_var,grad_new,1,grad,1);
  if(a<=1e-4)
    for(i=0;i<n_var;i++)
      grad[i]=0;
  return 1;
}


