#include "rans.h"

/*
* SUPER-DUPER RANDOM NUMBER GERNERATOR
*
* ANSI C version of Marsaglia's "super-duper" random number
* generator.
*
* Random number generator used in Berkeley ISP and S.
*
* USAGE:
*
*    uint32 lran(void);			returns a random 32 bit unsigned int
*    double rans(void);			returns a random double uniformly
*						distributed in (0,1)
*    int intran(int low, int high);	returns random signed int x, such
*						that low <= x <= high
*    void getsd(uint32 *c, uint32 *t);	put current values of two seeds in
*						c and t
*    void setsd(uint32 c, uint32 t);	set current seeds
*
* DESCRIPTION:
*
* Two independent generators are maintained internally:
* a linear congruential generator with multiplier 69069 and modulus 2^32;
* and a Tausworthe generator based on primitive trinomial x^32 + x^17 + 1.
* The two seeds are XOR'd together to give the random number.
*
* cseed must be odd, and tseed must be nonzero in order to obtain the
* full period.
*
* The Tausworthe generator has period length 2^32 - 1, and the congruential
* generator has period 2^30.  Because the congruential and Tausworthe
* generators are independent and have relatively prime periods, the ultimate
* period is (2^30) * (2^32 - 1), or about 2^62.
*
*/

static uint32 cseed = 12345u;
static uint32 tseed = 1073u;
static uint32 multiplier = 69069;

/*
 * Zero extension on the left and right shifts is guaranteed by ANSI C
 * for unsigned operands.  Unsigned multiplication is guaranteed to give
 * correct result mod 2^32 if uint32 is 32-bit type.
 */

#define UNI \
	tseed ^= (tseed >> 15); \
	tseed ^= (tseed << 17); \
	cseed *= multiplier

/* 32 bit random unsigned integer */
uint32 lran(void) {
  UNI;
  return cseed ^ tseed;
}

/* double precision uniform (0,1) random variate */
double rans(void) {
  register uint32 foo;
  do {
    UNI;
    foo = tseed ^ cseed;
  } while (foo == 0);
  return ((double) foo) / 4294967296.0;
}

/* random integer between low and high (inclusive) */
int intran(int low, int high)
{
  return low + (int) (rans() * (high + 1 - low));
}

/* set seed values */
void setsd(uint32 c, uint32 t)
{
  /* enforce cseed odd and tseed nonzero */
  cseed = c | 1;
  tseed = t != 0 ? t : 1;
}

/* get seed values */
void getsd(uint32 *cp, uint32 *tp)
{
  *cp = cseed;
  *tp = tseed;
}


int  bernoulli_f(double p)
{
 
  return (rans()<p);
  
}

int  rand_discrete_f(double *cdf,int *values)
{
  int x;
  double u;
  int i,index;
  
  index=1;

   u = rans();

   while(u >= cdf[index])
   index=index+1;

   x = values[index];
   return x;

  
}


void get_seeds(const char *fname)
{
	FILE *file;
	uint32 cseed, tseed;

	if (fname == NULL)
		fname = ".Random.seed";

	if ((file = fopen(fname, "r")) == NULL) {
		fprintf(stderr, "Cannot open file %s for read\n", fname);
		perror((char *) NULL);
		exit(1);
	}

	if (fscanf(file, "%x %x", &cseed, &tseed) != 2) {
		fprintf(stderr, "Cannot read seeds from file %s\n", fname);
		exit(1);
	}

	fclose(file);

/* 	printf("\n %08x %08x\n", cseed, tseed); */

	if (cseed % 2 == 0) {
		fprintf(stderr, " cseed must be odd\n");
		exit(1);
	}
	if (tseed == 0) {
		fprintf(stderr, " tseed must be nonzero\n");
		exit(1);
	}

	setsd(cseed, tseed);
}

void put_seeds(const char *fname)
{
	FILE *file;
	uint32 cseed, tseed;

	getsd(&cseed, &tseed);

/* 	printf("\n %08x %08x\n", cseed, tseed); */

	if (fname == NULL)
		fname = ".Random.seed";

	if ((file = fopen(fname, "w")) != NULL) {
		fprintf(file, " %08x %08x\n", cseed, tseed);
		fclose(file);
		return;
	} else {
		fprintf(stderr, "Cannot open %s for write\n", fname);
		perror((char *) NULL);
		exit(1);
	}
}
int  rand_int_f(int n)
{
   return (ceil(rans()*n));
  
}

int ksub_random ( int n, int k, int a[] )

//******************************************************************************
//
//  Purpose:
//
//    KSUB_RANDOM3 selects a random subset of size K from a set of size N.
//
//  Discussion:
//
//    This routine uses Floyd's algorithm.
//
//  Modified:
//
//    29 May 2003
//
//  Parameters:
//
//    Input, int N, the size of the set from which subsets are drawn.
//
//    Input, int K, number of elements in desired subsets.  K must
//    be between 0 and N.
//
//    Input/output, int *SEED, a seed for the random number generator.
//
//    Output, int A[N].  I is an element of the subset
//    if A(I) = 1, and I is not an element if A(I)=0.
//
{
  int i;
  int j;
  double r;

  if ( k < 0 || n < k )
  {
    printf( "\n");
    printf( "KSUB_RANDOM3 - Fatal error!\n");
    printf( "  N = %5d\n", n);
    printf( "  K = %5d\n",k);
    printf( "  but 0 <= K <= N is required!\n");
    exit ( 1 );
  }

  for ( i = 0; i < n; i++ )
  {
    a[i] = 0;
  }

  if ( k == 0 )
  {
    return;
  }

  for ( i = n-k+1; i <= n; i++ )
  {
    j=rand_int_f(i);

    if ( a[j-1] == 0 )
    {
      a[j-1] = 1;
    }
    else
    {
      a[i-1] = 1;
    }

  }

  return;
}


int ksub_random_split ( int n, int k, int *ranks )
{
/*   this function randomly splits integers 0-(N-1) into two groups,  */
/*   of k and n-k elements. It stores the first k in positions 0-(k-1) */
/*   of vector ranks and the rest on in the last n-k positions */
  int i,j=0,l=k;
  int indexes[n];
  
  ksub_random(n,k,indexes);
  
  for(i=0;i<n;i++)
    {
      if(indexes[i]==1)
        {
          ranks[j]=i;
          j++;
        }else
        {
          ranks[l]=i;
          l++;
        }
    }
  return 1;
}
