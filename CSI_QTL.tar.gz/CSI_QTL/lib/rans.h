/*
* Define uint32 to be a 32 bit unsigned integer type.  If there isn't one,
* the code would have to be rewritten to emulate 32 bit arithmetic.
*/

#ifndef STUFFDEF_H
#define STUFFDEF_H 

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stddef.h>
#include <time.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/times.h>
#include <sys/types.h>

#ifdef  DEFINE_DATA
#define GLOBAL
#else
#define GLOBAL extern
#endif  /*DEFINE_DATA*/

#define PPI  2*M_PI             /*  2-pi for use in Normal densities   */

#define EXIT_MALLOC 44			/*exit status code for malloc	*/
					/*failure			*/

typedef unsigned int uint32;    /*this works on RISC workstations*/
GLOBAL time_t start_time;		/*start time for program executn*/


/* typedef unsigned int uint32;	*/     /*this works on RISC workstations*/
                                       /*moved to stuff.h               */

#define CONGRUENTIAL_SEED 12345u	/*default seed values		*/
#define TAUSWORTHE_SEED   1073u	


GLOBAL double rans(void);
GLOBAL double normal(double, double);
GLOBAL void get_seeds(const char *fname);
GLOBAL void put_seeds(const char *fname);
GLOBAL int rand_int(double *work, int k );
GLOBAL void permute(int *ab, int n);
GLOBAL int bernoulli_f(double p);
GLOBAL int rand_discrete_f(double *cdf,int *values);
GLOBAL int rand_int_f(int n);
GLOBAL int ksub_random(int n, int k, int a[]);
GLOBAL int ksub_random_split(int n, int k, int *ranks);





extern uint32 lran(void);
extern int intran(int low, int high);
extern void getsd(uint32 *cseed, uint32 *tseed);
extern void setsd(uint32 cseed, uint32 tseed);

#endif /*RANS_H*/






