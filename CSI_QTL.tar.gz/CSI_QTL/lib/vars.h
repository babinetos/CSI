
/* #define add_info 6 */
#define max_alleles 2
#define max_locs 1
#define max_families 500
#define max_fam_members 60
#define max_nuc_families 20
#define max_members 312
#define max_markers 10000
#define max_ite 100
/* #define TOL .00000001 */


/* Map discription variables */

int markers,map,mark_ranks[max_markers+3],parents[3];
double locations[max_locs+1];
double distances[max_markers];
int alleles[max_markers+2];
double proportions[max_markers+2][max_alleles+1];
double marker_locations[max_locs+1];

/* IBD sharing probabilities variables*/
int size,n_locs,parents[3],add_info;
double p_mis,trans_mats[max_locs+1][2][4][4];
double forward_prob[max_families+1][max_markers +2][4],backward_prob[max_families+1][max_markers +2][4];
double ibd_share[max_families+1][max_locs+1][3];


/* Regression Vars */ 

double sqr_diff_sib_pheno[max_families+1];

/* exact calculation variables*/
int low_marker[max_locs+2],closest_marker[max_locs+2];
double family_ids[(max_families+1)*(max_nuc_families+1)][5];
int nuc_family[max_markers+1][5][3];



/* simulation Variables */

double trans_mark_inher_mat[max_markers][17][17];
double flank_trans_inher_mat[3][17][17];
int inher_vectors[17][5];
double cdf_proportions[max_markers+2][max_alleles+1];
int ibd_vecs[3][9],tot_ibd_vecs[3];
int genos[max_families+1][max_markers+1][5][3];
