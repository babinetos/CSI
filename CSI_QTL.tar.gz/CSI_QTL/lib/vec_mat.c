#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* #include <gsl/gsl_cblas.h>  */
#include "cblas.h"
#include  "vec_mat.h"

#define FALSE 0
#define TRUE  1

#define TOOSMALL ((double) 1.0e-119)
#define FREE_ARG char*



DMATRIX alloc_DMATRIX(int nr,int nc)
{
  int i;
  DMATRIX m;
 
  m.rows=nr;
  m.cols=nc;
  m.arr=(double *) calloc((nr)*(nc),sizeof(double));
  m.mat=(double **) calloc(nr,sizeof(double *));
  for (m.mat[0] = m.arr, i = 1; i < nr; i++)
    m.mat[i] = &m.arr[i * (nc)];
  
  return m;
}

/* ####################################### */

void free_DMATRIX(DMATRIX m, int nr)
//* free an int matrix allocated by imatrix() */
{
  int i;
  free((FREE_ARG) (m.arr));
  for(i=0;i<nr;i++)
    free((FREE_ARG) (m.mat[i]));
  free((FREE_ARG) (m.mat));
}



/* ####################################### */

double *dvector(int n)
{
        double *v;

        v=(double *) calloc(n+1,sizeof(double));
        if (!v) fprintf(stderr, "allocation failure in dvector(), Size %3d\n",n);
/* 	if (!v) fprintf(stderr, "allocation failure in dvector()"); */
        return v;
}
/* ####################################### */

void free_dvector(double *v)
/* free a double vector allocated with dvector() */
{
free((FREE_ARG) (v));
}


/* ####################################### */

double **dmatrix(int nr,int nc)
{
        int i;
        double **m;

        m=(double **) calloc(nr+1,sizeof(double*));
        if (!m) fprintf(stderr, "allocation failure 1 in dmatrix()");

        for(i=0;i<=nr;i++) {
	  m[i]=(double *) calloc(nc+1,sizeof(double));
                if (!m[i]) fprintf(stderr, "allocation failure 2 in dmatrix()");        }
        return m;
}

/* ####################################### */

void free_dmatrix(double **m, int nr)
//* free an int matrix allocated by imatrix() */
{
  int i;
  for(i=0;i<=nr;i++) 
    free((FREE_ARG) (m[i]));
  free((FREE_ARG) (m));
}

/* ####################################### */
int *ivector(int n)
{
        int *v;

        v=(int *)calloc(n+1,sizeof(int));
        if (!v) fprintf(stderr, "allocation failure in ivector(), Size %3d\n",n);
/*         if (!v) fprintf(stderr, "allocation failure in ivector()"); */
        return v;
}
/* ####################################### */


int **imatrix(int nr,int nc)
{
        int i;
        int **m;

        m=(int **) calloc(nr+1,sizeof(int*));
        if (!m) fprintf(stderr, "allocation failure 1 in dmatrix()");

        for(i=0;i<=nr;i++) {
	  m[i]=(int *) calloc(nc+1,sizeof(int));
                if (!m[i]) fprintf(stderr, "allocation failure 2 in dmatrix()");        }
        return m;
}



/* ####################################### */


int cholesky_f(double **A, double **L, int N, int *nullity)
/*
Inputs:
	N, integer
	A, N x N matrix _indexed_from_1_
Returns:
	L, N x N matrix, _indexed_from_1_, you must allocate before
		calling this routine,
	nullity, integer
*/
{
  int row, j, k;
  double sum;
  *nullity = 0;
  for (row=0; row<N; row++) {
    /* First compute L[row][row] */
/*     sum = A[row][row] - cblas_ddot(row,L[row],1,L[row],1); */
    sum = A[row][row];
    for (j=0; j<=(row-1); j++) sum -= L[row][j]*L[row][j];
    if (sum > TOOSMALL) {

      L[row][row] = sqrt(sum);
      /* Now find elements L[row][k], k > row. */
      for (k=(row+1); k<N; k++) {
	
	sum = A[row][k];
    for (j=0; j<=(row-1); j++) sum -= L[row][j]*L[k][j];
/* 	sum = A[row][k]; */
/* 	sum -= cblas_ddot(row,L[row],1,L[k],1); */

	L[k][row]  = sum/L[row][row];
	L[row][k]=0;
      }
    }
    else {/* blast off the entire row. */
      for (k=row; k<N; k++) L[row][k] = 0.0;
      (*nullity)++;
    }
/*     printf("%3d\t%7.3f\n",row,sum); */
  }
  
  return 1;
}

/*################################################################*/

/* This one starts from M[1][1] */
int cholesky(double **A, double **U, int N, int *nullity)
/*
Inputs: 
        N, integer
        A, N x N matrix _indexed_from_1_
Returns:
        U, N x N matrix, _indexed_from_1_, you must allocate before
                calling this routine,
        nullity, integer
*/
{
  int row, j, k;
  double sum;

  *nullity = 0;
  for (row=1; row<=N; row++) {
    /* First compute U[row][row] */
    sum = A[row][row];
    for (j=1; j<=(row-1); j++) sum -= U[j][row]*U[j][row];
    if (sum > TOOSMALL) {
      U[row][row] = sqrt(sum);
      /* Now find elements U[row][k], k > row. */
      for (k=(row+1); k<=N; k++) {
        sum = A[row][k];
        for (j=1; j<=(row-1); j++) 
          sum -= U[j][row]*U[j][k];
        U[row][k]  = sum/U[row][row];
        U[k][row]=0;
      }
    }
    else {      /* blast off the entire row. */
      for (k=row; k<=N; k++) U[row][k] = 0.0;
      (*nullity)++;
    }
  }
  return 1;
}



/*################################################################*/

double det_chol_inv_mat_f(int n, DMATRIX m,DMATRIX mi )
   /*    m is the cholesky decomposition of the matrix to invert
         mi is the inverse matrix
         numrows is the number of rows and columns in m.
	 This function returns the det of the the matrix
	 in addition to the inverse (it is used for the MVN).
   */
{
   int i,j;
   double D=1;
   double temp[n*n];


   cblas_dcopy(n*n,m.arr,1,temp,1);

   for(i=0;i<n;i++)
     D*=m.mat[i][i];
   D*=D;
   for(i=0;i<n;i++)
     {
       mi.mat[i][i]=1;
       for(j=0;j<i;j++)
	 mi.mat[i][j]=mi.mat[j][i]=0;
     }
   cblas_dtrsm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
   cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
    return D;
}



/*################################################################*/

int inv_mat_f(int n, DMATRIX m,DMATRIX mi )
   /*    m is the matrix to invert
         mi is the inverse matrix
         numrows is the number of rows and columns in m.
	 This function returns the det of the the matrix
	 in addition to the inverse (it is used for the MVN).
   */
{
   int i,j;
   double temp[n*n];

   /* Perform Cholesky decomposition on m */
   cholesky_f(m.mat,mi.mat,n,&i);
   cblas_dcopy(n*n,mi.arr,1,temp,1);

   for(i=0;i<n;i++)
     {
       mi.mat[i][i]=1;
       for(j=0;j<i;j++)
	 mi.mat[i][j]=mi.mat[j][i]=0;
     }
   cblas_dtrsm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
   cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
    return 0;
}



double log_det_chol_inv_mat_f(int n, DMATRIX m,DMATRIX mi )
   /*    m is the cholesky decomposition of the matrix to invert
         mi is the inverse matrix
         numrows is the number of rows and columns in m.
	 This function returns the det of the the matrix
	 in addition to the inverse (it is used for the MVN).
   */
{
   int i,j;
   double D=0;
   double temp[n*n];

   /* Perform Cholesky decomposition on m */

   cblas_dcopy(n*n,m.arr,1,temp,1);

   for(i=0;i<n;i++)
     D+=log(m.mat[i][i]);
   D*=2;
   for(i=0;i<n;i++)
     {
       mi.mat[i][i]=1;
       for(j=0;j<i;j++)
	 mi.mat[i][j]=mi.mat[j][i]=0;
     }
   cblas_dtrsm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
   cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,n);
    return D;
}



/* ####################################### */
/* ####################################### */
/* ####################################### */
/* ####################################### */
























/* ####################################### */

int print_vec_f(int n,double *vec, char *format,int s)
{
  int i;
  for(i=0+s;i<n+s;i++)
    printf(format,vec[i]);
  printf("\n");
  return 1;
}
       
/* ####################################### */

int print_mat_f(int rows,int cols,double **mat, char *format,int s)
{
  int i;
  for(i=0+s;i<rows+s;i++)
    print_vec_f(cols,mat[i],format,s);
  printf("\n");
  return 1;
}
/* ####################################### */

int fprint_vec_f(FILE *out, int n,double *vec, char *format,int s)
{
  int i,flag=0;
      for(i=0+s;i<n+s;i++)
	fprintf(out,format,vec[i]);
      fprintf(out,"\n");
  return 1;
}
/* ####################################### */

int fprint_mat_f(FILE *out,int rows,int cols,double **mat, char *format,int s)
{
  int i;
  for(i=0+s;i<rows+s;i++)
    fprint_vec_f(out,cols,mat[i],format,s);
  return 1;
}
       


/* ####################################### */
/* ####################################### */

double log_det_inv_mat_f(int n,DMATRIX m,DMATRIX mi)
   /*    m is the matrix to invert
         mi is the inverse matrix
         numrows is the number of rows and columns in m.
	 This function returns the det of the the matrix
	 in addition to the inverse (it is used for the MVN).
   */
{
   int i,j,k;
   double D=0;
   double temp[n*n];

   /* Perform Cholesky decomposition on m */
   cholesky_f(m.mat,mi.mat,n,&i);

   k=0;
   for(i=0;i<n;i++)
     for(j=0;j<n;j++)
       {
	 temp[k]=mi.mat[i][j];
	 k++;
       }

   for(i=0;i<n;i++)
     D+=log(mi.mat[i][i]);
   D*=2;

   for(i=0;i<n;i++)
     {
       mi.mat[i][i]=1;
       for(j=0;j<i;j++)
	 mi.mat[i][j]=mi.mat[j][i]=0;
     }
   cblas_dtrsm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,mi.rows);
   cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,mi.rows);


    return D;
}
