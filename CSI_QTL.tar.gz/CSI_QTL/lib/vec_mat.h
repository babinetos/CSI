
typedef struct DMATRIX {
  int rows;
  int cols;
  double *arr;  /* memory block to store matrix elements */
  double **mat; /* addresses of 1st ellement of each row */
} DMATRIX;


double *dvector(int n);
double **dmatrix(int nr,int nc);
int *ivector(int n);
int **imatrix(int nr,int nc);


int cholesky_f(double **A, double **L, int N, int *nullity);
int cholesky(double **A, double **U, int N, int *nullity);


double det_chol_inv_mat_f(int n, DMATRIX m,DMATRIX mi );
double log_det_chol_inv_mat_f(int n, DMATRIX m,DMATRIX mi );


double log_det_inv_mat_f(int n, DMATRIX m,DMATRIX mi );


int inv_mat_f(int n, DMATRIX m,DMATRIX mi );


int print_vec_f(int n,double *vec, char *format,int s);
int print_mat_f(int rows,int cols,double **mat, char *format,int s);
int fprint_vec_f(FILE *out, int n,double *vec, char *format,int s);
int fprint_mat_f(FILE *out,int rows,int cols,double **mat, char *format,int s);


DMATRIX alloc_DMATRIX(int nr,int nc);
void free_DMATRIX(DMATRIX m, int nr);
