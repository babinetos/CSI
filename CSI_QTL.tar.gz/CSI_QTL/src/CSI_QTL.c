
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "files.h"
#include "rans.h"
#include "vec_mat.h"
#include "distributions.h"
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_cblas.h>

#include <gsl/gsl_roots.h>

/* #include "cblas.h" */
/* #include "vars.h" */
#include "like_vars.h"

int PART_ALLELE_DIST[2][max_markers][4];

int ALLELE_DIST[max_markers][4];

int fdf_mininize_f( const gsl_vector *x,gsl_multimin_function_fdf my_func,gsl_multimin_fdfminimizer *s, double init_step, int max_iter, double tol)
{
  int iter=0,status;
  
  gsl_multimin_fdfminimizer_set (s, &my_func, x, init_step,tol);
     
  do
    {
      iter++;
      status = gsl_multimin_fdfminimizer_iterate (s);
     
      if (status)
	break;
     
      status = gsl_multimin_test_gradient (s->gradient, tol);
      
    }
       while (status == GSL_CONTINUE && iter < max_iter);
 
  return status;
}


double b_grid_loglike_f(double *sigmas, double **lims,int *points, double *bmaxs);

double gsl_logL_f(const gsl_vector *v, void *params);
void gsl_grad_logL_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_logL_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);

double log_L_beta_sigma_f(double *betas,double *sigmas);
double log_L_f(double *x, double *pars);
int grad_L_f(double *x, double *grad, double *pars);

double rand_unif_f(double a, double b)
{
  double u;
  u=rans();
  
  u=a+u*(b-a);
  return u;
}


int main (int argc, char **argv)
{
  int i,j,m,tns;
  int arg;
  FILE *out,*limits;
  ln2pi=log(2*PI);
  TEMP_MAT=alloc_DMATRIX(max_members,max_members);
  char pedfile[MAXLEN] = "pedigree";
  char mapfile[MAXLEN] = "marker.loc";
  char outfile[MAXLEN] = "CSI_out.txt";
  char limfile[MAXLEN] = "lims.txt";
  char cmd[20];
  int independent=0; /* Chencks if pedfile has only unrelated indivs */
  int steps=1,nsteps=1,n,l;
  double incre=1,offend=0;
  int mode=0,multipoint=1;
/*   double stats[max_locs+1][2]; */
  int analysis=0,estimate=1,inlims=0;
  int freq=1,ALL=0; /* freq controls if alle frequencies will be estimated ftom data or provided. "ALL" controls if only founders (0) or all (1) will be used to estimate the frequencies */
  p_mis=.15;
  map=0;
  alpha=.05;
  maxite=100;
  TOL = 10E-6;
  nsigmas=2;
  if (argc > 1) {
      for (arg=1; arg < argc && argv[arg][0] == '-'; arg++) {
         switch (argv[arg][1])
            {
            case 'p':
               strncpy(pedfile, argv[++arg], MAXLEN);
               fflush(stdout);
               break;
	    case 'm':
               strncpy(mapfile, argv[++arg], MAXLEN);
               break;
	    case 'f':
               strncpy(mapfile, argv[++arg], MAXLEN);
	       freq=0;
               break;
	    case 'o':
               strncpy(outfile, argv[++arg], MAXLEN);
               break;
 	    case 'l':
               strncpy(limfile, argv[++arg], MAXLEN);
	       inlims=1;
               break;
              break;
            case '-':
	      
	      strncpy(cmd, &argv[arg][2], 15);

	      if( !strcmp(cmd,"IND"))
		independent=1;

	      if( !strcmp(cmd,"nofreq"))
		freq=0;

	      if( !strcmp(cmd,"ALL"))
		ALL=1;

	      if( !strcmp(cmd,"steps"))
		nsteps=atoi(argv[++arg]);

	      if( !strcmp(cmd,"grid"))
		{
		  steps=0;
		  incre=atof(argv[++arg]);
		}
	      if( !strcmp(cmd,"rec"))
		{
		  if(!strcmp(argv[++arg],"K"))
		    map=1;
		}

	      if( !strcmp(cmd,"screen"))
		screen = 1;

 	      if( !strcmp(cmd,"offend"))
		{
		  steps=0;
		  offend=atof(argv[++arg]);
		}

	      if( !strcmp(cmd,"alpha"))
		alpha=atof(argv[++arg]);

	      if( !strcmp(cmd,"TOL"))
		TOL=atof(argv[++arg]);

	      if( !strcmp(cmd,"maxite"))
		maxite=atoi(argv[++arg]);

	      if( !strcmp(cmd,"nsigmas"))
		{
		  nsigmas=atoi(argv[++arg]);
		  if(nsigmas>2 || nsigmas < 0)
		    {
		      fprintf (stderr, "Number of variance components (nsigmas) should be between 0 and 2.\n", argv[arg]);
		      exit(1);
		    }
		}
  	      if( !strcmp(cmd,"sim"))
		sim=1;
             break;

            default:
               fprintf (stderr, "Unknown option \"%s\"\n", argv[arg]);
               exit(1);
            }
      }
   }





  double sa_tot;
  double eps=.03,p0;

  if(freq==0)
    {
      vc_read_marker_info_f(mapfile);
    }else
    read_map_info_f(mapfile);

  /* Reading the Pedigree information */

  if( independent == 1 && ALL==0)
    {
      read_ind_ped_f(pedfile);
    }else
    {
      i= vc_read_ped_f(pedfile);
      if(independent != 1)
	independent==i;
    }



  if(independent ==1)
    nsigmas=0;
  slims=dmatrix(nsigmas+1,2);
  spoints=ivector(nsigmas+1);

  for(i=0;i<=nsigmas;i++)
    {
       slims[i][0]=1;
       slims[i][1]=30;
       spoints[i]=10;
     }

  blims=dmatrix(peds[0].ncovars,2);
  bpoints=ivector(peds[0].ncovars);
  for(i=0;i<peds[0].ncovars;i++)
    {
      blims[i][0]=-50;
      blims[i][1]=50;
      bpoints[i]=10;
    }

  char line[MAXLEN];

  if(inlims ==1)
    {
      limits=open_f(limfile,'r');
       for(i=0;i<peds[0].ncovars;i++)
	{
	  fgets(line, MAXLEN,limits);
	  sscanf(line,"%lf%lf%d",&blims[i][0],&blims[i][1],&bpoints[i]);
	}
     
      for(i=0;i<=nsigmas;i++)
	{
	  fgets(line, MAXLEN,limits);
	  sscanf(line,"%lf%lf%d",&slims[i][0],&slims[i][1],&spoints[i]);
	}
    }
 
   set_cov_mats();

   out=open_f(outfile,'a');

  double bmaxs[peds[0].ncovars],smaxs[nsigmas];
  double *grad,L,L0,MAF;
  int n_tot=peds[0].ncovars+nsigmas,conv=0;
  double x[n_tot];
  double *pars;
  DMATRIX H,H1;

  /* NO major gene effect */

  H=alloc_DMATRIX(n_tot,n_tot);
  for(i=0;i<n_tot;i++)
    for(j=0;j<n_tot;j++)
      H.mat[i][j]=0;
  for(i=0;i<n_tot;i++)
    H.mat[i][i]=1.0;
  grad=dvector(n_tot);

  if( sim != 1)
    {
      fprintf(out,"=========================================\n");
      fprintf(out,"=     Information on Input Files        =\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"\n");
      fprintf(out,"Pedigree File:\t\t\t%s\n",pedfile);
      fprintf(out,"Marker Description File:\t%s\n",mapfile);
      fprintf(out,"Output File:\t\t\t%s\n",outfile);
      fprintf(out,"\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"=         Analysis Information          =\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"\n");
      fprintf(out,"Number of families:\t\t\t%5d\n",npeds);
      fprintf(out,"Number of Markers in Pedfile:\t\t%5d\n",MAP.nm);
      fprintf(out,"Number of Covariates in Pedfile:\t%5d\n",peds[0].ncovars);
      fprintf(out,"Number of Genetic Variance Components:\t%5d\n",nsigmas-1);
      fprintf(out,"Confidence Level:\t\t\t%5.0f%\n",100*(1-alpha));
 
      fprintf(out,"Estimation of Allele frequencies:\t  ");
      if(freq==0)
	{
	  fprintf(out,"User Defined through file %s.\n",mapfile);
	}else
	{
	  if(ALL==1)
	    {
	      fprintf(out,"Using ALL individuals in pedigree file.\n");
	    }else
	    fprintf(out,"Using only Founders in pedigree file.\n");
	}

/*       fprintf(out,"Individuals assumed UNRELATED:\t\t"); */
/*       if(independent==1) */
/* 	{ */
/* 	  fprintf(out,"Yes\n"); */
/* 	}else */
/* 	fprintf(out,"No\n"); */
/*         if(independent==1) */
/* 	{ */
/* 	  fprintf(out,"Individuals used in analysis:\t\t"); */
/* 	  if(ALL==1) */
/* 	    { */
/* 	      fprintf(out,"ALL\n"); */
/* 	    }else */
/* 	    fprintf(out,"Founders\n"); */
/* 	} */
      fprintf(out,"\n");
      fprintf(out,"\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"= Overall Polygenic variance components =\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"\n");
      fprintf(out,"    LogL\t-2logLR\t");
  
      
      for(i=0;i<peds[0].ncovars;i++)
	fprintf(out,"   b%1d\t sd(b%1d)\t",i,i);
      
      fprintf(out,"  s_e\tsd(s_e)\t");
      
      if(nsigmas > 1)
	fprintf(out,"  s_a\tsd(s_a)\t");
      if(nsigmas > 2)
	fprintf(out,"  s_d\tsd(s_d)\t");
    

      fprintf(out,"\n");
      for(i=0;i<2*n_tot+3;i++)
	fprintf(out,"-------\t");
      fprintf(out,"\n");
      
      if( screen == 1 )
	{
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"=     Information on Input Files        =\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"Pedigree File:\t\t\t%s\n",pedfile);
	  fprintf(stdout,"Marker Description File:\t%s\n",mapfile);
	  fprintf(stdout,"Output File:\t\t\t%s\n",outfile);
	  fprintf(stdout,"\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"=         Analysis Information          =\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"Number of families:\t\t\t%5d\n",npeds);
	  fprintf(stdout,"Number of Markers in Pedfile:\t\t%5d\n",MAP.nm);
	  fprintf(stdout,"Number of Covariates in Pedfile:\t%5d\n",peds[0].ncovars);
	  fprintf(stdout,"Number of Genetic Variance Components:\t%5d\n",nsigmas-1);
	  fprintf(stdout,"Confidence Level:\t\t\t%5.0f%\n",100*(1-alpha));
	  fprintf(stdout,"Estimation of Allele frequencies:\t  ");
	  if(freq==0)
	    {
	      fprintf(stdout,"User Defined through file %s.\n",mapfile);
	    }else
	    {
	      if(ALL==1)
		{
		  fprintf(stdout,"Using ALL individuals in pedigree file.\n");
		}else
		fprintf(stdout,"Using only Founders in pedigree file.\n");
	    }

/* 	  fprintf(stdout,"Individuals assumed UNRELATED:\t\t"); */
/* 	  if(independent==1) */
/* 	    { */
/* 	      fprintf(stdout,"Yes\n"); */
/* 	    }else */
/* 	    fprintf(stdout,"No\n"); */
/* 	  if(independent==1) */
/* 	    { */
/* 	      fprintf(stdout,"Individuals used in analysis:\t\t"); */
/* 	      if(ALL==1) */
/* 		{ */
/* 		  fprintf(stdout,"ALL\n"); */
/* 		}else */
/* 		fprintf(stdout,"Founders\n"); */
/* 	    } */
	  
	  fprintf(stdout,"\n");
	  fprintf(stdout,"\n");
	  
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"= Overall Polygenic variance components =\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"    LogL\t-2logLR\t");
	  



	  for(i=0;i<peds[0].ncovars;i++)
	    fprintf(stdout,"   b%1d\t sd(b%1d)\t",i,i);

	  fprintf(stdout,"  s_e\tsd(s_e)\t");
	  
	  if(nsigmas > 1)
	    fprintf(stdout,"  s_a\tsd(s_a)\t");
	  if(nsigmas > 2)
	    fprintf(stdout,"  s_d\tsd(s_d)\t");


/* 	  for(i=1;i<nsigmas;i++) */
/* 	    fprintf(stdout,"   s%1d\t sd(s%1d)\t",i,i); */


	  fprintf(stdout,"\n");
	  for(i=0;i<2*n_tot+3;i++)
	    fprintf(stdout,"-------\t");
	  fprintf(stdout,"\n");
	}
    }
    
  /* No genetic effect */



  tns=nsigmas;
  nsigmas=1;
  n_tot=peds[0].ncovars+nsigmas;


  /* Maximization Stuff */

  gsl_multimin_function_fdf log_L_fdf;
  const gsl_multimin_fdfminimizer_type *T;
  gsl_multimin_fdfminimizer *s0,*s1,*s2;


  log_L_fdf.f = &gsl_logL_f;
  log_L_fdf.df = &gsl_grad_logL_f;
  log_L_fdf.fdf = &gsl_both_logL_f;
  log_L_fdf.n =n_tot ;
  log_L_fdf.params = &pars;
  T = gsl_multimin_fdfminimizer_vector_bfgs;
  s0 = gsl_multimin_fdfminimizer_alloc (T,n_tot);

  gsl_vector *gsl_x;
  gsl_x = gsl_vector_alloc (n_tot);


  double **lims,step=4;
  int points[n_tot];

  lims=dmatrix(n_tot,2);
  for(i=0;i<peds[0].ncovars;i++)
    {
      lims[i][0]=blims[i][0];
      lims[i][1]=blims[i][1];
      points[i]=bpoints[i];
    }
  i=peds[0].ncovars;
  lims[i][0]=slims[0][0];
  lims[i][1]=slims[0][1];
  points[i]=spoints[0];

  max_grid_log_L_f(n_tot, lims,points, pars,x);
  cblas_dcopy(n_tot,x,1,gsl_x->data,1);

  fdf_mininize_f(gsl_x,log_L_fdf,s0,.01,maxite,TOL);
  cblas_dcopy(n_tot,s0->x->data,1,x,1);
  L=s0->f;
  gsl_multimin_fdfminimizer_free (s0);
  gsl_vector_free (gsl_x);

  joint_cov_f(x,H);
  
  if( sim != 1)
    {
      fprintf(out,"%14.4f\t  --- \t",-L);
      for(i=0;i<peds[0].ncovars;i++)
	fprintf(out,"%7.3f\t%7.3f\t",x[i],sqrt(H.mat[i][i]));
      for(i=peds[0].ncovars;i<n_tot;i++)
	fprintf(out,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H.mat[i][i]));
      fprintf(out,"\n");
      
      if( screen == 1 )
	{
	  fprintf(stdout,"%14.4f\t  --- \t",-L);
	  for(i=0;i<peds[0].ncovars;i++)
	    fprintf(stdout,"%7.3f\t%7.3f\t",x[i],sqrt(H.mat[i][i]));
	  for(i=peds[0].ncovars;i<n_tot;i++)
	    fprintf(stdout,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H.mat[i][i]));
	  fprintf(stdout,"\n");
	}
    }



  L0=L;
  nsigmas=tns;
  n_tot=peds[0].ncovars+nsigmas;
  for(i=peds[0].ncovars+1;i<n_tot;i++)
    x[i]=(slims[i-peds[0].ncovars][1]-slims[i-peds[0].ncovars][0])/2;



  gsl_x = gsl_vector_alloc (n_tot);
  log_L_fdf.n =n_tot ;
  log_L_fdf.params = &pars;
  s1 = gsl_multimin_fdfminimizer_alloc (T,n_tot);


  cblas_dcopy(n_tot,x,1,gsl_x->data,1);

  fdf_mininize_f(gsl_x,log_L_fdf,s1,.01,maxite,TOL);

  cblas_dcopy(n_tot,s1->x->data,1,x,1);
  L=s1->f;
  gsl_multimin_fdfminimizer_free (s1);
  gsl_vector_free (gsl_x);

  joint_cov_f(x,H);


  if( sim != 1)
    {
      fprintf(out,"%14.4f\t%7.3f\t",-L,2*(L0-L));
      for(i=0;i<peds[0].ncovars;i++)
	fprintf(out,"%7.3f\t%7.3f\t",x[i],sqrt(H.mat[i][i]));
      for(i=peds[0].ncovars;i<n_tot;i++)
	fprintf(out,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H.mat[i][i]));
      fprintf(out,"\n");

      if( screen == 1 )
	{
	  fprintf(stdout,"%14.4f\t%7.3f\t",-L,2*(L0-L));
	  for(i=0;i<peds[0].ncovars;i++)
	    fprintf(stdout,"%7.3f\t%7.3f\t",x[i],sqrt(H.mat[i][i]));
	  for(i=peds[0].ncovars;i<n_tot;i++)
	    fprintf(stdout,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H.mat[i][i]));
	  fprintf(stdout,"\n");
	}
    }

  if( sim == 1)
    {
      fprintf(out,"%14.4f\t%7.3f\t",-L0,-2*(L0-L));
      for(i=0;i<peds[0].ncovars;i++)
	fprintf(out,"%7.3f\t%7.3f\t",x[i],sqrt(H.mat[i][i]));
      for(i=peds[0].ncovars;i<n_tot;i++)
	fprintf(out,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H.mat[i][i]));
    }
  if(independent == 1)
    {
      sa_tot=fabs(x[peds[0].ncovars]);
    }else
    sa_tot=fabs(x[peds[0].ncovars+1]);

/* /\*################################################################*\/ */
/* /\*################################################################*\/ */

/*             /\* Variance Components Analysis *\/ */

/* /\*################################################################*\/ */
/* /\*################################################################*\/ */
  int PART_ALLELE_DIST[2][4];
  int ALLELE_DIST[4];
  int ntot=0,ngen;

  for(i=0;i<npeds;i++)
    ntot+=peds[i].npeople;

  int types[ntot],statuses[ntot];

  if(analysis == 0)
    {

      L0=L;
      
      n_tot++;
      
      H1=alloc_DMATRIX(n_tot,n_tot);
      for(i=0;i<n_tot;i++)
	for(j=0;j<n_tot;j++)
	  H1.mat[i][j]=0;
      for(i=0;i<n_tot;i++)
	H1.mat[i][i]=1.0;
      
      for(i=0;i<npeds;i++)
	peds[i].ncovars++;
      
      
  if( sim != 1)
    {
      fprintf(out,"\n");
      fprintf(out,"\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"=     Variance Components Analysis      =\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"\n");
      fprintf(out,"\n");
      fprintf(out,"=========================================\n");
      fprintf(out,"=              Major genes              =\n");
      fprintf(out,"=========================================\n");
      
      fprintf(out,"\n");
      fprintf(out,"Marker\t");
      if(freq!=0)
	fprintf(out,"      Name\t");
      fprintf(out,"  Loc  \t  MAF\tGamma0\t     LogL\t-2logLR\t");
      

      for(i=0;i<peds[0].ncovars-1;i++)
	fprintf(out,"   b%1d\t sd(b%1d)\t",i,i);
      fprintf(out,"  g_t\tsd(g_t)\t");
      
      fprintf(out,"  s_e\tsd(s_e)\t");
      
      if(nsigmas > 1)
	fprintf(out,"  s_a\tsd(s_a)\t");
      if(nsigmas > 2)
	fprintf(out,"  s_d\tsd(s_d)\t");


      fprintf(out,"%2.0f% UB(p)\t",100*(1-alpha));
      fprintf(out,"\n");
      fprintf(out,"-------\t");
      if(freq!=0)
	fprintf(out,"--------------\t");
      for(i=1;i<8+2*n_tot;i++)
	fprintf(out,"-------\t");
      fprintf(out,"\n");

      if( screen == 1 )
	{
	  fprintf(stdout,"\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"=     Variance Components Analysis      =\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"\n");
	  fprintf(stdout,"=========================================\n");
	  fprintf(stdout,"=              Major genes              =\n");
	  fprintf(stdout,"=========================================\n");
	  
	  fprintf(stdout,"\n");
	  fprintf(stdout,"Marker\t");
	  if(freq!=0)
	    fprintf(stdout,"     Name\t");
	  fprintf(stdout,"  Loc  \t  MAF\tGamma0\t     LogL\t-2logLR\t");
	  
	  for(i=0;i<peds[0].ncovars-1;i++)
	    fprintf(stdout,"   b%1d\t sd(b%1d)\t",i,i);
	  fprintf(stdout,"  g_t\tsd(g_t)\t");
	  
	  fprintf(stdout,"  s_e\tsd(s_e)\t");
	  
	  if(nsigmas > 1)
	    fprintf(stdout,"  s_a\tsd(s_a)\t");
	  if(nsigmas > 2)
	    fprintf(stdout,"  s_d\tsd(s_d)\t");
	  
	  fprintf(stdout,"%2.0f% UB(p)\t",100*(1-alpha));
	  fprintf(stdout,"\n");
	  fprintf(stdout,"-------\t");
	  if(freq!=0)
	    fprintf(stdout,"--------------\t");
	  for(i=1;i<8+2*n_tot;i++)
	    fprintf(stdout,"-------\t");
	  fprintf(stdout,"\n");

	}
    }

  for(i=n_tot;i>=peds[0].ncovars;i--)
    x[i]=x[i-1];
  x[peds[0].ncovars-1]=0;



  gsl_x = gsl_vector_alloc (n_tot);
  log_L_fdf.n =n_tot ;
  s2 = gsl_multimin_fdfminimizer_alloc (T,n_tot);


  cblas_dcopy(n_tot,x,1,gsl_x->data,1);
  for(m=0;m<MAP.nm;m++)
    {
      j=0;
      for(i=0;i<nsigmas;i++)
	if(fabs(x[peds[0].ncovars+i]) < .0001)
	  j++;

      if(j==nsigmas)
	{
	   for(i=0;i<n_tot;i++)
	      for(j=0;j<n_tot;j++)
	        H1.mat[i][j]=0;
	    for(i=0;i<n_tot;i++)
	      H1.mat[i][i]=1.0;
	    for(i=0;i<nsigmas;i++)
	      x[peds[0].ncovars+i]=1;
	}

      if(freq==1)
	{
	  for(i=0;i<4;i++)
	    {
	      ALLELE_DIST[i]=0;
	      PART_ALLELE_DIST[0][i]=0;
	      PART_ALLELE_DIST[1][i]=0;
	    }
	  
	  allele_marker_binary_genos_f(m,types,statuses);
	  
	  for(i=0;i<ntot;i++)
	    {
	      ALLELE_DIST[types[i]]++;
	      PART_ALLELE_DIST[statuses[i]][types[i]]++;
	    }
	  ngen=PART_ALLELE_DIST[0][1]+PART_ALLELE_DIST[0][2]+PART_ALLELE_DIST[0][3];
	  MAF=(double)(PART_ALLELE_DIST[0][1]+.5*PART_ALLELE_DIST[0][2])/ngen;
	  if(ALL==1)
	    {
	      ngen=ALLELE_DIST[1]+ALLELE_DIST[2]+ALLELE_DIST[3];
	      MAF=(double)(ALLELE_DIST[1]+.5*ALLELE_DIST[2])/ngen;
	    }
	  if(MAF>.5)
	    MAF=1-MAF;
	  MAP.ps[m+1][1]=MAF;
	}
      


      marker_binary_genos_f(m);
      conv = 0;
      
      fdf_mininize_f(gsl_x,log_L_fdf,s2,.01,maxite,TOL);
      
      cblas_dcopy(n_tot,s2->x->data,1,x,1);
      L=s2->f;

      joint_cov_f(x,H1);

      /* Computing the allele frequencies from the data themselves */

     i=peds[0].ncovars-1;

      p0=2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])*pow((fabs(x[i])+cndev(1-alpha)*sqrt(H1.mat[i][i]))/sa_tot,2);

     if( sim != 1)
       {
	 fprintf(out,"%7d\t",m+1);
	 if(freq!=0)
	 fprintf(out,"%-14s\t",MAP.names[m+1]);
	 fprintf(out,"%7.3f\t",MAP.locs[m+1]);
	 MAF=MAP.ps[m+1][1];
	 if(MAF>.5)
	   MAF=1-MAF;
	 if( pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])) < 1000)
	   {
	     fprintf(out,"%7.5f\t%7.3f\t",MAF,pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])));
	   }else
	     fprintf(out,"%7.5f\t%7.0f\t",MAF,pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])));

	 fprintf(out,"%14.3f\t%7.2f\t",-L,2*(L0-L));
	 for(i=0;i<peds[0].ncovars;i++)
	   if(sqrt(H1.mat[i][i]) < 1000)
	     {
	       fprintf(out,"%7.3f\t%7.3f\t",x[i],sqrt(H1.mat[i][i]));
	     }else
	       fprintf(out,"%7.3f\t%7.0f\t",x[i],sqrt(H1.mat[i][i]));

	 for(i=peds[0].ncovars;i<n_tot;i++)
	   if(sqrt(H1.mat[i][i]) < 1000)
	     {
	       fprintf(out,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H1.mat[i][i]));
	     }else
	       fprintf(out,"%7.3f\t%7.0f\t",fabs(x[i]),sqrt(H1.mat[i][i]));

	 fprintf(out,"%7.5f\t",p0);
	 fprintf(out,"\n");
	 
	 if( screen == 1 )
	   {
	 fprintf(stdout,"%7d\t",m+1);
	 if(freq!=0)
	 fprintf(stdout,"%-14s\t",MAP.names[m+1]);
	 fprintf(stdout,"%7.3f\t",MAP.locs[m+1]);
	 MAF=MAP.ps[m+1][1];
	 if(MAF>.5)
	   MAF=1-MAF;
	 if( pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])) < 1000)
	   {
	     fprintf(stdout,"%7.5f\t%7.3f\t",MAF,pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])));
	   }else
	   fprintf(stdout,"%7.5f\t%7.0f\t",MAF,pow(sa_tot,2)/sqrt(2*MAP.ps[m+1][1]*(1-MAP.ps[m+1][1])));

	 
	 fprintf(stdout,"%14.3f\t%7.2f\t",-L,2*(L0-L));
	 for(i=0;i<peds[0].ncovars;i++)
	   if(sqrt(H1.mat[i][i]) < 1000)
	     {
	       fprintf(stdout,"%7.3f\t%7.3f\t",x[i],sqrt(H1.mat[i][i]));
	     }else
	     fprintf(stdout,"%7.3f\t%7.0f\t",x[i],sqrt(H1.mat[i][i]));

	 for(i=peds[0].ncovars;i<n_tot;i++)
	   if(sqrt(H1.mat[i][i]) < 1000)
	     {
	       fprintf(stdout,"%7.3f\t%7.3f\t",fabs(x[i]),sqrt(H1.mat[i][i]));
	     }else
	       fprintf(stdout,"%7.3f\t%7.0f\t",fabs(x[i]),sqrt(H1.mat[i][i]));

	     fprintf(stdout,"%7.5f\t",p0);
	     fprintf(stdout,"\n");
	   }
	  
       }

      if( sim == 1)
	{
      	  fprintf(out,"%7.3f\t%7.2f\t",MAP.locs[m+1],2*(L0-L));
	  i=peds[0].ncovars-1;
	  fprintf(out,"%7.3f\t%7.3f\t%7.5f\t",x[i],sqrt(H1.mat[i][i]),p0);
	}
	    
    }
      if( sim == 1)
	fprintf(out,"\n");
 
     gsl_multimin_fdfminimizer_free (s2);
      gsl_vector_free (gsl_x);

    }


  return 0;
}

/*################################################################*/
/*################################################################*/


int allele_marker_binary_genos_f(int m, int *types, int *found_stat)
{
  int i,j,f,a1,p=0;

  for(f=0;f<npeds;f++)
    {
      for(i=0;i<peds[f].npeople;i++)
	{
	  a1=-2;
	  for(j=0;j<2;j++)
	    a1+=peds[f].genos[i][m][j];

	  if(a1<0)
	    a1=-1;
	  a1++;
 
	  types[p]=a1;


	  found_stat[p]=0;
	  if(peds[f].f_ids[i]!=0)
	    found_stat[p]=1;

	  p++;

/* 	  printf("%3d\t%3d\t%3d\t%3d\t%3d\t%3d\t%3d\n",f,i,peds[f].genos[i][m][0],peds[f].genos[i][m][1],types[p-1],peds[f].f_ids[i],found_stat[p-1]); */
	}
    }
  return p;
}


/* /\*################################################################*\/ */

/* int reg_multi_ibd_f(char *ped_file,int n_locs,double locations[max_locs+1]) */
/* { */
/* /\*******************************************************************\/ */
/* /\*   this function reads the file with n families and calculates   *\/ */
/* /\*   the number of nuclear families in the file, and also computes *\/ */
/* /\*   multipoint IBD sharings at each loci l for each pair of affected*\/  */
/* /\*   sib-pair                                                      *\/ */
/* /\*******************************************************************\/ */

/*   int i,j,k,l,n,m,f,s1,s2,p,par; */
/*   int family[max_markers+1][5][3]; */
/*   FILE *pedigree; */

/*   double family_id, current_family; */
/*   int families[max_members+1][7],family_genos[max_markers+1][max_fam_members+1][3]; */
/*   int nuclear_families[max_nuc_families+1][max_fam_members+1]; */
/*   int uninfo,members,founders,flag; */
/*   int aff,aff_sibs; */
/*   int ncov,geno_sibs; */
/*   char line[MAXLEN]; */
/*   double fam_phenos[max_members+1]; */

/* /\*   pedigree= fopen(ped_file ,"r"); *\/ */
/*   pedigree= open_f(ped_file, 'r'); */
/*   fgets(line, MAXLEN,pedigree); */
/*   sscanf(line,"%lf",&current_family); */
/*   i=word_cnt(line); */
/*   ncov=i-(add_info+2*markers+1); */
/*   rewind(pedigree); */
/*   founders = 0; */
/*   members=0; */
/*   flag = 1; */

/*   for(p=0;p<3;p++)	 */
/*     parents[p]=0;	 */

/* /\*   printf("%3d\n",add_info); *\/ */
/*   n=0; */
/*   while (flag < 2) */
/*     { */

/*       if(fscanf(pedigree,"%lf",&family_id) != 1) */
/* 	{ */
/* 	  family_id = -23; */
/* 	  flag++; */
/* 	}      */
/* /\*       printf("%7.0f\t%7.0f\n",family_id,current_family); *\/ */
  
/*      if(family_id != current_family) */
/*        { */
/* 	 f=split_to_nuclear_f(families,members,founders,nuclear_families); */

/* 	 for(i=1;i<=f;i++) */
/* 	   { */
	     
/* 	     par=0; */
/* 	     for(p=1;p<3;p++) */
/* 	       par+=family_genos[0][nuclear_families[i][p]][0]; */

/* 	     geno_sibs=0;  */
/* 	     for(j=3;j<= nuclear_families[i][0];j++) */
/* 		 geno_sibs +=family_genos[0][nuclear_families[i][j]][0]; */


/* 	     if(geno_sibs>=2) */
/* 	       { */
/* 		 family[0][0][0]=(int)current_family; */
/* 		 for(p=1;p<3;p++) */
/* 		   family[0][p][0]=families[nuclear_families[i][p]][1]; */

/* 		 for(p=1;p<3;p++) */
/* 		   for(m=1;m<=markers;m++) */
/* 		     for(j=1;j<3;j++) */
/* 		       family[m][p][j]=family_genos[m][nuclear_families[i][p]][j]; */
		 
/* 		 for( s1=3;s1<nuclear_families[i][0];s1++) */
/* 		   if(family_genos[0][nuclear_families[i][s1]][0]>0) */
/* 		   { */
/* 		     family[0][3][0]=families[nuclear_families[i][s1]][1]; */
/* 		     for(m=1;m<=markers;m++) */
/* 		       for(j=1;j<3;j++) */
/* 			 family[m][3][j]=family_genos[m][nuclear_families[i][s1]][j]; */
 
/* 		     for( s2=s1+1;s2<=nuclear_families[i][0];s2++) */
/* 		       if(family_genos[0][nuclear_families[i][s2]][0]>0) */
/* 		       { */
/* 			 family[0][4][0]=families[nuclear_families[i][s2]][1]; */
/* 			 n++; */
/* 			 parents[par]++; */
/* 			 family_ids[n][0]=current_family; */
/* 			 family_ids[n][1]=(double)families[nuclear_families[i][s1]][1]; */
/* 			 family_ids[n][2]=(double)families[nuclear_families[i][s2]][1]; */

/* 			 for(m=1;m<=markers;m++) */
/* 			   for(j=1;j<3;j++) */
/* 			     family[m][4][j]=family_genos[m][nuclear_families[i][s2]][j]; */
/* 			 sqr_diff_sib_pheno[n]= pow(fam_phenos[nuclear_families[i][s1]]- fam_phenos[nuclear_families[i][s2]],2)	; */

/* /\* 			 printf("%7.3f\t%7.3f\t%7.3f\n",fam_phenos[nuclear_families[i][s1]],fam_phenos[nuclear_families[i][s2]],sqr_diff_sib_pheno[n]); *\/ */
/* 			 family_multi_ibd_f(n_locs,locations,family,ibd_share[n]); */

/* 		       } */
/* 		   } */
/* 	       } */
/*        } */
       	 

/* 	 founders=0; */
/* 	 members =0; */
/* 	 current_family = family_id; */
/*        }    */
 
/*      members++; */
/* /\*      printf("%3d\n",members); *\/ */
/*      for(i=1;i<=add_info-1;i++) */
/*        fscanf(pedigree,"%d",&families[members][i]); */
     
/*      if( families[members][2]== 0 && families[members][3] == 0) */
/*        founders++; */
     
/*      uninfo=0; */
/*      for(i=1;i<=markers;i++) */
/*        { */
/* 	 for(j=1;j<3;j++) */
/* 	   { */
/* 	     fscanf(pedigree,"%d",&family_genos[i][members][j]);	      */
/* 	     uninfo+=family_genos[i][members][j]; */
/* /\* 	     printf("%3d\t",family_genos[i][members][j]); *\/ */
/* 	   } */
/* /\* 	 printf("%3d\n",uninfo); *\/ */
/*        } */

/*      family_genos[0][members][0]=1; */
/*      if(uninfo==0) */
/*        family_genos[0][members][0]=0; */
/*      /\*      printf("%3d\t%3d\t%3d\n",members,uninfo,family_genos[0][members][0]); *\/  */
/*      for(i=1;i<=ncov;i++) */
/*        fscanf(pedigree,"%*lf"); */
/*      fscanf(pedigree,"%lf",&fam_phenos[members]); */
/*  /\*     printf("%3d\t%7.3f\n",families[members][i],fam_phenos[members]); *\/ */
/*     } */
  
/* /\*   printf("%3d\n",n); *\/ */

/*   return n; */
  
/* } */




/* int print_IBD_f(char *ibd_file, int analysis) */
/* { */
/*   int n,l,i; */
/*   FILE *out; */

/*   out= open_f(ibd_file,'w'); */
/*   printf("\%3d\t%3d\n",analysis,size); */
/*   fprintf(out,"%7s\t%7s\t%7s\t%6s\t%7s\t%7s\t%7s\n","Family"," Sib1 "," Sib2 ", " Loc ","  z_0 ","  z_1 ","  z_2 "); */
/*   if( analysis == 1) */
/*     { */
/*       for(n=1;n<=size;n++) */
/* 	for(l=1;l<=n_locs;++l) */
/* 	  { */
	    
/* 	    fprintf(out,"%7.2f\t%7.0f\t%7.0f\t%6.2f \t",family_ids[n][0],family_ids[n][1],family_ids[n][2],locations[l]); */
/* 	    for(i=0;i<3;i++) */
/* 	      fprintf(out,"%7.5f\t",ibd_share[n][l][i]); */
/* 	    fprintf(out,"\n"); */
/* 	  } */
/*     }else */
/*       { */
/* 	for(n=1;n<=size;n++) */
/* 	  for(l=1;l<=markers;++l) */
/* 	    { */
	    
/* 	      fprintf(out,"%7.2f\t%7.0f\t%7.0f\t%6.2f \t",family_ids[n][0],family_ids[n][1],family_ids[n][2],locations[mark_ranks[l]]); */
/* 	      for(i=0;i<3;i++) */
/* 		fprintf(out,"%7.5f\t",ibd_share[n][mark_ranks[l]][i]); */
/* 			fprintf(out,"\n"); */
		      
/* 	    } */
/*       } */
/*   fclose(out); */
/*  return 0; */
/* } */

/*################################################################*/
/*################################################################*/

int VAR_MAT_f(int nsigmas, PED_t ped, DMATRIX *V)
{
  int i,j;
  int maxid =0;
  for(i=0;i<ped.npeople;i++)
    if(ped.p_ids[i] > maxid)
      maxid=ped.p_ids[i];
  
  int orders[maxid+1];
  for(i=0;i<ped.npeople;i++)
    orders[ped.p_ids[i]]=i;
  
  ADD_VAR_MAT_f(ped,orders,V[1]);
  if( nsigmas>1)
    {
      DOM_VAR_MAT_f(ped,orders,V[2]);
  
    }
}


int DOM_VAR_MAT_f(PED_t ped, int *orders, DMATRIX V)
{
  int i,j;
  int f,m;
  int nnf=0, included[ped.npeople];

  for(i=0;i<ped.npeople;i++) 
    included[i]=0;
  for(i=0;i<ped.npeople;i++)
    {
      V.mat[i][i]=1;
      if(ped.f_ids[i]*ped.m_ids[i]>0)
	{
	  f=ped.f_ids[i];
	  m=ped.m_ids[i];
	  for(j=i+1;j<ped.npeople;j++)
	    if(ped.f_ids[j]==f && ped.m_ids[j]==m)
	      {
		V.mat[i][j]= V.mat[j][i]=.25;
		included[j]=1;
	      }
	}
      included[i]=1;
    }

  return 1;
}





int ADD_VAR_MAT_f(PED_t ped, int *orders, DMATRIX V)
{
  int i,j;
  int nf=0, founders[ped.npeople], ancestors[ped.npeople];
  int nnf=0, nonfounders[ped.npeople];

  for(i=0;i<ped.npeople;i++)
    {
    if(ped.f_ids[i]*ped.m_ids[i] == 0)
      {
	founders[nf]=ped.p_ids[i];
	nf++;
      }else
      {
	nonfounders[nnf]=ped.p_ids[i];
	nnf++;
      }
    }

  for(i=0;i<ped.npeople;i++)
    for(j=0;j<=i;j++)
      V.mat[i][j]=V.mat[j][i]=-1;

  int k,l,r; 
  for(i=0;i<nf;i++)
    {
      k=orders[founders[i]];
      V.mat[k][k]=.5;
      for(j=0;j<i;j++)
	{
	  l=orders[founders[j]];
	  V.mat[k][l]=V.mat[l][k]=0;
	}
    }


  int unrelated_founders[nf];
  for(i=0;i<nnf;i++)
    {
      k=orders[nonfounders[i]];
      r = unrelated_founders_f(nonfounders[i],nf,founders,ped,orders,unrelated_founders);
      
      for(j=0;j<r;j++)
	{
	  l=orders[unrelated_founders[j]];
	  V.mat[k][l]=V.mat[l][k]=0;
	}
    }
  
  int f,m;
  for(i=0;i<ped.npeople;i++)
    {
      if(V.mat[i][i]==-1)
	{
	  f=orders[ped.f_ids[i]];
	  m=orders[ped.m_ids[i]];
	  V.mat[i][i]=.5*(1+V.mat[f][m]);
	}
      for(j=0;j<i;j++)
	if(V.mat[i][j]==-1)
	  V.mat[i][j]=V.mat[j][i]=.5*(V.mat[f][j]+V.mat[m][j]);
    }
    for(i=0;i<ped.npeople;i++)
    {
      V.mat[i][i] *=2;
      for(j=0;j<i;j++)
	V.mat[i][j] = V.mat[j][i] = 2*V.mat[i][j];
    }

  return 0;
}






int unrelated_founders_f(int person,int nf, int *founders, PED_t ped,int *orders, int *unrel_found)
{
  int i,j,flag,na,nu=0;
  int ancest[ped.npeople];

  na=ancestors_f(person,ped,orders,ancest);

  for(i=0;i<nf;i++)
    {
      flag=1;
      for(j=0;j<na;j++)
	if(founders[i]==ancest[j])
	  flag=0;
      if(flag==1)
	{
	  unrel_found[nu]=founders[i];
	  nu++;
	}
    }
  return nu;

}

int ancestors_f(int person, PED_t ped,int *orders, int *ancest)
{
  int i,j,na=0,t;
  int included[ped.npeople];
  int flag;

  for(i=0;i<ped.npeople;i++)
    included[i]=0;

  included[orders[person]]=1;
  if(ped.f_ids[orders[person]] !=0)
    {
      ancest[na] = ped.f_ids[orders[person]];
      included[orders[ancest[na]]]=1;
      na++;
    }
  
  if(ped.m_ids[orders[person]] !=0)
    {
      ancest[na] = ped.m_ids[orders[person]];
      included[orders[ancest[na]]]=1;
      na++;
    }

  flag=1;
  while(flag ==1)
    {
      flag=0;
      t=na;
      for(i=0;i<t;i++)
	{
	  j=orders[ancest[i]];

	  if(ped.f_ids[j] !=0 )
	    if(included[orders[ped.f_ids[j]]]!=1 )
	    {
	      ancest[na] = ped.f_ids[j];
	      included[orders[ancest[na]]]=1;
	      na++;
	      flag=1;
	    }

  if(ped.m_ids[j] !=0 )
    if(included[orders[ped.m_ids[j]]]!=1 )
	    {
	      ancest[na] = ped.m_ids[j];
	      included[orders[ancest[na]]]=1;
	      na++;
	      flag=1;
	    }
	}

      t=na;

   }
  return(na);
}


int set_cov_mats()
{
  int i,j,k,l,n,p,np;
  FILE *var;
  V_MATS=(DMATRIX **)calloc(npeds,sizeof(DMATRIX)); 
  np=0;

  for(p=0;p<npeds;p++)
    {
     n=peds[p].npeople;
      if(n>np)
	np=n;
      
      V_MATS[p]=(DMATRIX *)calloc(nsigmas+1,sizeof(DMATRIX));
      for(k=0;k<=nsigmas;k++)
	V_MATS[p][k]=alloc_DMATRIX(n,n);
      
      k=0;
      for(i=0;i<n;i++)
	{
	  V_MATS[p][k].mat[i][i]=1;
	  for(j=i+1;j<n;j++)
	    V_MATS[p][k].mat[j][i]=V_MATS[p][k].mat[i][j]=0;
	}
      if(nsigmas >0)
	VAR_MAT_f(nsigmas,peds[p],V_MATS[p]); 
    }

  nsigmas++;
  VS=alloc_DMATRIX(np,np);
  VSI=alloc_DMATRIX(np,np);
  
  GI_mats=(DMATRIX *)calloc(nsigmas,sizeof(DMATRIX));
  for(i=0;i<nsigmas;i++)
    GI_mats[i]=alloc_DMATRIX(np,np);
   return 1;
}
/*################################################################*/
/*################################################################*/

/*################################################################*/
/*################################################################*/

int V_hat_f(double *sigmas,int n, DMATRIX *VMATS, DMATRIX V)
{
  /* Computes the over all Covariance matrix */
  int i,j;
  for(i=0;i<n;i++)
    {
      V.mat[i][i]=0;
      for(j=0;j<i;j++)
	V.mat[i][j]=V.mat[j][i]=0;
    }
  for(j=0;j<nsigmas;j++)
    for(i=0;i<n;i++)
      cblas_daxpy(n,pow(sigmas[j],2),VMATS[j].mat[i],1,V.mat[i],1);
    return 1;
}
/*################################################################*/
double log_det_inv_mat1_f(int n,DMATRIX m,DMATRIX mi)
   /*    m is the matrix to invert
         mi is the inverse matrix
         numrows is the number of rows and columns in m.
	 This function returns the det of the the matrix
	 in addition to the inverse (it is used for the MVN).
   */
{
   int i,j,k;
   double D=0;
   double temp[n*n];

   /* Perform Cholesky decomposition on m */
   cholesky_f(m.mat,mi.mat,n,&i);
/*    print_mat_f(n,n,mi.mat,"%.4g\t",0); */

   k=0;
   for(i=0;i<n;i++)
     for(j=0;j<n;j++)
       {
	 temp[k]=mi.mat[i][j];
	 k++;
       }
/*    printf("%.6f\n",D); */
   for(i=0;i<n;i++)
     {
       D+=log(mi.mat[i][i]);
/*        printf("%3d\t%.3g\t%.3g\t%.6f\n",i,D,mi.mat[i][i],log(mi.mat[i][i])); */
     }
/*    printf("OK %.6f\n",D); */
   D*=2;

/*    double **temp1; */
/*    temp1=dmatrix(n,n); */
/*    for(i=0;i<n;i++) */
/*      for(j=0;j<n;j++) */
/*        temp1[i][j]=mi.mat[i][j]; */

/*   print_mat_f(n,n,temp1,"%.4g\t",0); */

/*    cholesky_f(temp1,temp1,n,&i); */
/*   print_mat_f(n,n,temp1,"%.4g\t",0); */
/*   D=0;  */
/*   for(i=0;i<n;i++) */
/*      { */
/*        D+=log(temp1[i][i]); */
/*        printf("NEW %3d\t%.3g\t%.3g\t%.6f\n",i,D,temp1[i][i],log(temp1[i][i])); */
/*      } */

   for(i=0;i<n;i++)
     {
       mi.mat[i][i]=1;
       for(j=0;j<i;j++)
	 mi.mat[i][j]=mi.mat[j][i]=0;
     }
   printf("OK %.6f\t %3d\n",D,mi.cols);
   cblas_dtrsm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,mi.cols);
   printf("OK %.6f\n",D);
   cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasTrans,CblasNonUnit,n,n,1,temp,n,mi.arr,mi.cols);

   printf("D %.6g\n",D);
    return D;
}

/* double log_L_beta_sigma_f(double *betas,double *sigmas) */
/* { */

/*   double L=0,T; */
/*   double temp[max_members]; */
/*   double u[max_members]; */
/*   int p; */
/*   for(p=0;p<npeds;p++) */
/*     { */
/*       V_hat_f(sigmas,peds[p].npeople,V_MATS[p],VS); */
/*       print_mat_f(peds[p].npeople,peds[p].npeople,VS.mat,"%.4g\t",0); */
/*       DET=log_det_inv_mat1_f(peds[p].npeople,VS,VSI); */
/*       printf("DET %.5g\n",DET); */
/*       print_mat_f(peds[p].npeople,peds[p].npeople,VSI.mat,"%.4g\t",0); */

/*       cblas_dcopy(peds[p].npeople,peds[p].phenos,1,u,1); */
/*       if(peds[p].ncovars>0) */
/* 	cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].ncovars,-1.0,peds[p].covariates.arr,peds[p].covariates.cols,betas,1,1,u,1); */
/*       cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,u,1,0,temp,1); */
      
/*       T=cblas_ddot(peds[p].npeople,u,1,temp,1); */
/*       L+=-.5*(peds[p].npeople*ln2pi + DET + T ); */
/*       printf("%3d\t%.5g\t%.5g\n",p,L,DET); */
/*     } */
  
/*   return -L; */
/* } */
/*################################################################*/
double log_L_beta_sigma_f(double *betas,double *sigmas)
{

  double L=0,T;
  double temp[max_members];
  double u[max_members];
  int p;
/*   printf("%3d\n",npeds); */
/*   p=271; */
/*   print_vec_f(nsigmas,sigmas,"%.4g\t",0); */
  for(p=0;p<npeds;p++)
    {
/*   printf("%7f\n",peds[p].id); */
/*   printf("%3d\n",peds[p].npeople); */
      V_hat_f(sigmas,peds[p].npeople,V_MATS[p],VS);
/*       print_mat_f(peds[p].npeople,peds[p].npeople,VS.mat,"%.4g\t",0); */
      DET=log_det_inv_mat_f(peds[p].npeople,VS,VSI);
/*       printf("DET %.5g\n",DET); */
/*       print_mat_f(peds[p].npeople,peds[p].npeople,VSI.mat,"%.4g\t",0); */

      cblas_dcopy(peds[p].npeople,peds[p].phenos,1,u,1);
/*       print_vec_f(peds[p].npeople,u,"%.4g\t",0); */
      if(peds[p].ncovars>0)
	cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].ncovars,-1.0,peds[p].covariates.arr,peds[p].covariates.cols,betas,1,1,u,1);
/*        print_mat_f(peds[p].npeople,peds[p].ncovars,peds[p].covariates.mat,"%.4g\t",0); */
/*       print_vec_f(peds[p].npeople,u,"%.4g\t",0); */
     cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,u,1,0,temp,1);
/*        print_vec_f(peds[p].npeople,temp,"%.4g\t",0); */
     
      T=cblas_ddot(peds[p].npeople,u,1,temp,1);
      L+=-.5*(peds[p].npeople*ln2pi + DET + T );
/*       printf("%3d\t%.5g\t%.5g\t%.5g\n",p,T,L,DET); */
    }
  
  return -L;
}
/*################################################################*/
/* ################################################################ */

int grad_L_beta_sigma_f(double *betas, double *sigmas, double *grad)
{
  int i,s,j,k;
  double temp[max_members];
  double u[max_members];
  int p;
  double sum,T,t[nsigmas];
  double D=0;

 for(i=0;i<peds[0].ncovars+nsigmas;i++)
   grad[i]=0;

 for(p=0;p<npeds;p++)
   {
     V_hat_f(sigmas,peds[p].npeople,V_MATS[p],VS);
     DET=log_det_inv_mat_f(peds[p].npeople,VS,VSI);
     cblas_dcopy(peds[p].npeople,peds[p].phenos,1,u,1);
     if(peds[p].ncovars>0)
       cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].ncovars,-1.0,peds[p].covariates.arr,peds[p].covariates.cols,betas,1,1,u,1);
     cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,u,1,0,temp,1);
     cblas_dgemv(CblasRowMajor,CblasTrans,peds[p].npeople,peds[p].ncovars,1.0,peds[p].covariates.arr,peds[p].covariates.cols,temp,1,1,grad,1);
     
     for(j=0;j<nsigmas;j++)
       {
	 cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,V_MATS[p][j].arr,V_MATS[p][j].cols,0.0,GI_mats[j].arr,GI_mats[j].cols);
	 T=0;
	 for(i=0;i<peds[p].npeople;i++)
	   T+=GI_mats[j].mat[i][i];
	 cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,GI_mats[j].arr,GI_mats[j].cols,0.0,VS.arr,VS.cols);
	 cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,VS.arr,VS.cols,u,1,0,temp,1);
	 sum=cblas_ddot(peds[p].npeople,u,1,temp,1);
	 grad[j+peds[p].ncovars]+=-sigmas[j]*(T - sum);
       }
   }
 
 for(i=0;i<peds[0].ncovars+nsigmas;i++)
   grad[i]=-grad[i];
 
 return 1;
}

/* ################################################################ */


int max_grid_log_L_f(int nvar, double **lims, int *points, double *pars, double *xmaxs)
{
  int i,j,c,r,k,status=0;
  double steps[nvar],maxL=1000000000,L;
  int indexes[nvar];
  double x[nvar];

  for(i=0;i<nvar;i++)
    {
      indexes[i]=0;
      steps[i]=0;
      if(points[i]>1)
	steps[i]=(lims[i][1]-lims[i][0])/(points[i]-1);
    }

  while(status ==0)
    {
      for(i=0;i<nvar;i++)
	  x[i]=lims[i][0]+indexes[i]*steps[i];
	  
      L=log_L_f(x,pars);
 
      if(L < maxL)
	{
	  maxL=L;
	  cblas_dcopy(nvar,x,1,xmaxs,1);
	}
      status=update_indexes_f(nvar,indexes,points,0);	  
    }
   return 1;
}


/* ################################################################ */

int update_indexes_f(int n,int *indexes, int *max_index, int s)
{
  int i,status=0;

  indexes[n-1]++;
  for( i=n-2;i>=0;i--)
    if(indexes[i+1] >= max_index[i+1])
      {
	indexes[i+1]=s;
	indexes[i]++;
      }
  if(indexes[0]>= max_index[0])
    status=1;
  return status;
}



/* ################################################################ */


double log_L_f(double *x, double *pars)
{
  int i;
  double betas[peds[0].ncovars],sigmas[nsigmas],L;
  for(i=0;i<peds[0].ncovars;i++)
    betas[i]=x[i];
  for(i=0;i<nsigmas;i++)
    sigmas[i]=x[peds[0].ncovars+i];
  L=log_L_beta_sigma_f(betas,sigmas);
  return L;
}



/* ################################################################ */

int grad_L_f(double *x, double *grad, double *pars)
{
  int i;
  double betas[peds[0].ncovars],sigmas[nsigmas];
  for(i=0;i<peds[0].ncovars;i++)
    betas[i]=x[i];

  for(i=0;i<nsigmas;i++)
    sigmas[i]=x[peds[0].ncovars+i];
  grad_L_beta_sigma_f(betas,sigmas,grad);

  return 1;
}

/* ################################################# */ 

int vc_read_marker_info_f(char *loc_file)
{
/*****************************************************************/
/*   this function reads the marker information. It takes as an  */
/*   argument the name of a file whose format is the one for the */
/*   standard linkage programs. If all given distances are less  */
/*   than .5, the function automatically assumes that they are   */
/*   recombination fractions, and converts them into cM.         */
/*****************************************************************/

  int i,j,check=0;
  char junk[5000];
  FILE *mark_info;

  mark_info = open_f(loc_file,'r');
  fscanf(mark_info,"%d%5000[^\n]",&MAP.nm,junk);
  MAP.nm--;

  MAP.alleles=ivector(MAP.nm+1);
  MAP.locs=dvector(MAP.nm+1);
  MAP.dists=dvector(MAP.nm+1);
  MAP.recfrc=dvector(MAP.nm+1);
  MAP.ps=dmatrix(MAP.nm+1,max_alleles);

  fgetc(mark_info);
  fscanf(mark_info,"%5000[^\n]",junk);
  fgetc(mark_info);

  for(i=0;i<=MAP.nm;++i)
    fscanf(mark_info,"%d",&j);
  fscanf(mark_info,"%5000[^\n]",junk);
  fgetc(mark_info);
  
  for(i=1;i<=4;++i)
    {
      fscanf(mark_info,"%5000[^\n]",junk);
      fgetc(mark_info);
    }
  for(i=1;i<=MAP.nm;++i)
    {
      fscanf(mark_info,"%d%d%200[^\n]",&j,&MAP.alleles[i],junk);
      MAP.ps[i][0]=0;
      for (j = 1; j<=MAP.alleles[i];j++)
	fscanf(mark_info,"%lf",&MAP.ps[i][j]);
    }
  
 
  fscanf(mark_info,"%*d");
  fscanf(mark_info,"%200[^\n]",junk);
  fgetc(mark_info);
  
  for(i=1;i<=MAP.nm;++i)
    {
      fscanf(mark_info,"%lf",&MAP.dists[i]);
      if(MAP.dists[i] <= 0)
	MAP.dists[i]=.000001;
      
      if(MAP.dists[i] < .5)
	check++;
    }
  
  if( check == MAP.nm)
    {
      for(i=1;i<=MAP.nm;++i)
	MAP.recfrc[i]=MAP.dists[i];
      
      for(i=1;i<=MAP.nm;++i)
	MAP.dists[i]=rec_to_cM_f(map,MAP.dists[i]);
    }else
      {
/* 	for(i=1;i<=MAP.nm;++i) */
/* 	  MAP.recfrc[i]=cM_to_rec_f(map,MAP.dists[i]); */
	if( map ==0)
	  {
	    for(i=1;i<=MAP.nm;++i)
	      MAP.recfrc[i]=.5*(1-exp(-2*MAP.dists[i]/100));
	  }else{
	  for(i=1;i<=MAP.nm;++i)
	    MAP.recfrc[i]=.5*tanh(2*MAP.dists[i]/100);
	}
      }
  MAP.locs[1]=MAP.dists[1];
  for(i=2;i<=MAP.nm;++i)
    MAP.locs[i]=MAP.locs[i-1]+MAP.dists[i];
  fclose(mark_info);

  return 1;

  }

/*####################################################################*/

/* ################################################# */ 
#define NAMELEN 100

int read_map_info_f(char *loc_file)
{
/*****************************************************************/
/*   this function reads the marker information. It takes as an  */
/*   argument the name of a file whose format is the one for the */
/*   Merlin map file containing the number of chrom, the name of */
/*   the marker name, and the location of the marker             */
/*****************************************************************/

  int i,j,check=0;
  char junk[5000];
  char line[MAXLEN];
  FILE *mark_info;

  mark_info = open_f(loc_file,'r');
  MAP.nm=0;
  while( fgets(line, MAXLEN,mark_info))
    MAP.nm++;
  rewind(mark_info);


  MAP.locs=dvector(MAP.nm+1);
  MAP.ps=dmatrix(MAP.nm+1,max_alleles);
  MAP.names=(char **) calloc(MAP.nm+1,sizeof(char*));
  if (!MAP.names) fprintf(stderr, "allocation failure 1 in Marker Names");
  
  for(i=0;i<=MAP.nm;++i) {
    MAP.names[i]=(char *) calloc(NAMELEN,sizeof(char));
    if (!MAP.names[i]) fprintf(stderr, "allocation failure 2 in Marker Names");
  }
 
  for(i=1;i<=MAP.nm;++i)
    {
      fscanf(mark_info,"%*d%s%lf%200[^\n]",MAP.names[i],&MAP.locs[i],line);
/*       printf("%d\t%s\t%7.5f\n",i,MAP.names[i],MAP.locs[i]); */
    }
  return 1;

  }


int vc_read_ped_f(char *ped_file)
{

  int i,j,l,ncov,flag=0,ind=0;
  double current_family,temp;
  FILE *pedigree;
  char line[MAXLEN];
  int mems[100000];
  pedigree= open_f(ped_file ,'r');
  
  fgets(line, MAXLEN,pedigree);
  i=word_cnt(line);
  ncov=i-(add_info+2*MAP.nm+1);
  sscanf(line,"%lf",&current_family);
  rewind(pedigree);
  j=0;
  l=0;
  while( fgets(line, MAXLEN,pedigree))
    {
     
      sscanf(line,"%lf",&temp);
      l++;
      if(current_family != temp)
	{
	  mems[j]=l-1;
	  if(mems[j]==1)
	    ind++;
	  l=1;
	  j++;
	  current_family=temp;
	}
    }
  mems[j]=l;
  if(mems[j]==1)
    ind++;
  j++;
  rewind(pedigree);
  npeds=j;
  /* Checking if pedfile includes only independent indivs */
  if(ind==npeds)
    ind=1;
  peds=(PED_t *)calloc(npeds,sizeof(PED_t));

  for(i=0;i<npeds;i++)
    {
      peds[i].npeople=mems[i];
      peds[i].p_ids=ivector(mems[i]);
      peds[i].f_ids=ivector(mems[i]);
      peds[i].m_ids=ivector(mems[i]);
      peds[i].sexes=ivector(mems[i]);
      peds[i].phenos=dvector(mems[i]);
      peds[i].genos=(int ***)calloc(mems[i],sizeof(int*));
      for(j=0;j<mems[i];j++)
	{
	  peds[i].genos[j]=(int **)calloc(MAP.nm,sizeof(int*));
	  for(l=0;l<MAP.nm;l++)
	    peds[i].genos[j][l]=(int *)calloc(2,sizeof(int));
	}
      peds[i].ncovars=ncov;
      peds[i].covariates=alloc_DMATRIX(mems[i],ncov+1);
      for(j=0;j<mems[i];j++)
	{
	  
	  fscanf(pedigree,"%lf",&peds[i].id);
	  fscanf(pedigree,"%d",&peds[i].p_ids[j]);
	  fscanf(pedigree,"%d",&peds[i].f_ids[j]);
	  fscanf(pedigree,"%d",&peds[i].m_ids[j]);
	  fscanf(pedigree,"%d",&peds[i].sexes[j]);
	  for(l=0;l<MAP.nm;l++)
	    fscanf(pedigree,"%d%d",&peds[i].genos[j][l][0],&peds[i].genos[j][l][1]);
	  for(l=0;l<ncov;l++)
	    fscanf(pedigree,"%lf",&peds[i].covariates.mat[j][l]);
	  fscanf(pedigree,"%lf",&peds[i].phenos[j]);
	}
    }
  

  return ind;
  
}


int marker_binary_genos_f(int m)
{
  int i,j,f,a1;
  
  for(f=0;f<npeds;f++)
    {
      for(i=0;i<peds[f].npeople;i++)
	{
	  a1=-2;
	  for(j=0;j<2;j++)
	    a1+=peds[f].genos[i][m][j];
	  peds[f].covariates.mat[i][peds[f].ncovars-1]=a1;
	  
	  if(MAP.ps[m+1][1] < .5)
	    peds[f].covariates.mat[i][peds[f].ncovars-1]=2-a1;
	}
    }
}




double gsl_logL_f(const gsl_vector *v, void *params)
{
  return log_L_f(v->data,params);
}
void gsl_grad_logL_f(const gsl_vector *v, void *params,gsl_vector *df)
{
  grad_L_f(v->data,df->data,params);
}

void gsl_both_logL_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  *f =log_L_f(v->data,params);
  gsl_grad_logL_f(v,params,df);

}








int joint_cov_f(double *x,DMATRIX S) 
{
  int i,j,k,f,p;
  double b=0,sum;
  double u[max_members],temp[max_members],bs[peds[0].ncovars];

  double betas[peds[0].ncovars],sigmas[nsigmas],L;
  for(i=0;i<peds[0].ncovars;i++)
    betas[i]=x[i];
  for(i=0;i<nsigmas;i++)
    sigmas[i]=x[peds[0].ncovars+i];
  for(i=0;i<peds[0].ncovars+nsigmas;i++)
    for(j=0;j<=i;j++)
      S.mat[i][j]=S.mat[j][i]=0;

  DMATRIX Hb,Hbx;
  if(peds[0].ncovars > 0)
    {
      Hb=alloc_DMATRIX(peds[0].ncovars,peds[0].ncovars); 
      Hbx=alloc_DMATRIX(max_members,peds[0].ncovars); 
    }

  for(p=0;p<npeds;p++)
    {

      V_hat_f(sigmas,peds[p].npeople,V_MATS[p],VS);
      DET=log_det_inv_mat_f(peds[p].npeople,VS,VSI);
      cblas_dcopy(peds[p].npeople,peds[p].phenos,1,u,1);
      if(peds[p].ncovars>0)
	{
	cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].ncovars,-1.0,peds[p].covariates.arr,peds[p].covariates.cols,betas,1,1,u,1);
	/* Covariates part */

      cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,
		  peds[p].npeople,peds[p].ncovars,
		  1,VSI.arr,VSI.cols,
		  peds[p].covariates.arr,peds[p].covariates.cols,
		  0,Hbx.arr,Hbx.cols);
   
      cblas_dgemm(CblasRowMajor,CblasTrans, CblasNoTrans,
		  peds[p].ncovars,peds[p].ncovars,peds[p].npeople,
		  1.0,peds[p].covariates.arr,peds[p].covariates.cols,
		  Hbx.arr,Hbx.cols,
		  b,Hb.arr,Hb.cols);
	}
      b=1;

      for(i=0;i<nsigmas;i++)
	{
	  cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,V_MATS[p][i].arr,V_MATS[p][i].cols,0.0,GI_mats[i].arr,GI_mats[i].cols);
	}

      for(i=0;i<nsigmas;i++)
	{	  
	    /*Covariates-Variance Components Part */
	    if(peds[p].ncovars>0)
	      {
		for(j=0;j<peds[p].ncovars;j++)
		  bs[j]=0;
		cblas_dgemm(CblasRowMajor,CblasNoTrans, CblasNoTrans,
			    peds[p].npeople,peds[p].npeople,peds[p].npeople,
			    1.0,GI_mats[i].arr,GI_mats[i].cols,
			    VSI.arr,VSI.cols,
			    0.0,VS.arr,VS.cols);

		cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,VS.arr,VS.cols,u,1,0,temp,1);
		
		cblas_dgemv(CblasRowMajor,CblasTrans,peds[p].npeople,peds[p].ncovars,2*sigmas[i],peds[p].covariates.arr,peds[p].covariates.cols,temp,1,1,bs,1);
		
		for(j=0;j<peds[p].ncovars;j++)
		  {
		    S.mat[peds[p].ncovars+i][j]+=bs[j];
		    S.mat[j][peds[p].ncovars+i]=S.mat[peds[p].ncovars+i][j];
		  }

	      }

	    /* Variance Components Part */

	    for(j=0;j<=i;j++)
	      {
		cblas_dgemm(CblasRowMajor,CblasNoTrans, CblasNoTrans,
			    peds[p].npeople,peds[p].npeople,peds[p].npeople,
			    1.0,GI_mats[i].arr,GI_mats[i].cols,
			    GI_mats[j].arr,GI_mats[j].cols,
			    0.0,VS.arr,VS.cols);

		sum=0;
		for(k=0;k<peds[p].npeople;k++)
		  sum+=VS.mat[k][k];
		sum*=.5;

		cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,peds[p].npeople,peds[p].npeople,1.0,VSI.arr,VSI.cols,VS.arr,VS.cols,0.0,TEMP_MAT.arr,TEMP_MAT.cols);
		cblas_dgemv(CblasRowMajor,CblasNoTrans,peds[p].npeople,peds[p].npeople,1.0,TEMP_MAT.arr,TEMP_MAT.cols,u,1,0,temp,1);

		sum-=cblas_ddot(peds[p].npeople,temp,1,u,1);

		S.mat[peds[p].ncovars+j][peds[p].ncovars+i]-=sum*4*sigmas[i]*sigmas[j];
		S.mat[peds[p].ncovars+i][peds[p].ncovars+j]=S.mat[peds[p].ncovars+j][peds[p].ncovars+i];

	      }

	}
    }
  for(i=0;i<peds[0].ncovars;i++)
    for(j=i;j<peds[0].ncovars;j++)
      S.mat[i][j] = S.mat[j][i] = Hb.mat[i][j];
  
 
/*   print_mat_f(peds[0].ncovars+nsigmas,peds[0].ncovars+nsigmas,S.mat,"%7.4f\t",0); */

log_det_inv_mat_f(peds[0].ncovars+nsigmas,S,S);


/*  print_mat_f(peds[0].ncovars+nsigmas,peds[0].ncovars+nsigmas,S.mat,"%7.4f\t",0); */
/*   if(peds[0].ncovars > 0) */
/*     { */
/*       free_DMATRIX(Hb,peds[0].ncovars); */
/*       free_DMATRIX(Hbx,max_members); */
/*     } */


  return 1;
    }



int read_ind_ped_f(char *ped_file)
{

  int tpid,tfid,tmid,f;
  double tped;
  int i,j,l,ncov,flag=0,ind=0;
  double current_family,temp,f_id;
  FILE *pedigree;
  char line[MAXLEN],word[10];
  int mems[100000];
  pedigree= open_f(ped_file ,'r');
  
  fgets(line, MAXLEN,pedigree);
  i=word_cnt(line);
  ncov=i-(add_info+2*MAP.nm+1);
  sscanf(line,"%lf",&current_family);
  rewind(pedigree);
/*   printf("%7d\t%7d\t%7d\n",i,MAP.nm,ncov); */
/*   int n=0; */
/*   for(j=0;j<10;j++) */
/*     { */
/*       printf("%3d\t%s\n",i,sscanf ( line, "%4s%n", word, &n )); */
/*       line+=n; */
/*     } */

  j=0;
  while( fgets(line, MAXLEN,pedigree))
    {
       sscanf(line,"%*lf%*d%d%d",&i,&l);
/*       printf("%7d\t%7d\n",i,l); */
      if(i+l == 0)
	{
	  mems[j]=1;
	  j++;
	}
 /*  printf("%7d\n",j); */
    }

  rewind(pedigree);
  npeds=j;
/*   printf("%7d\n",j); */
  peds=(PED_t *)calloc(npeds,sizeof(PED_t));
  for(i=0;i<npeds;i++)
    {
      peds[i].npeople=mems[i];
      peds[i].p_ids=ivector(mems[i]);
      peds[i].f_ids=ivector(mems[i]);
      peds[i].m_ids=ivector(mems[i]);
      peds[i].sexes=ivector(mems[i]);
      peds[i].phenos=dvector(mems[i]);
      peds[i].genos=(int ***)calloc(mems[i],sizeof(int*));
      for(j=0;j<mems[i];j++)
	{
	  peds[i].genos[j]=(int **)calloc(MAP.nm,sizeof(int*));
	  for(l=0;l<MAP.nm;l++)
	    peds[i].genos[j][l]=(int *)calloc(2,sizeof(int));
	}
      peds[i].ncovars=ncov;
      peds[i].covariates=alloc_DMATRIX(mems[i],ncov+1);
      
      f=1;
      while( f > 0)
	{
	  fscanf(pedigree,"%lf%d%d%d",&tped,&tpid,&tfid,&tmid);
/* 	  printf("%lf\t%d\t%d\t%d\n",tped,tpid,tfid,tmid); */
	  f=tfid+tmid;
	  if(f > 0)
	    {
	      for(j=0;j< 2*MAP.nm + 1;j++)
		fscanf(pedigree,"%*d");
	      
	       for(l=0;l<ncov+1;l++)
		 fscanf(pedigree,"%*lf");
	    }	      
	}
       j=0;
      peds[i].id=tped;
      peds[i].p_ids[j]=tpid;
      peds[i].f_ids[j]=tfid;
      peds[i].m_ids[j]=tmid;

      fscanf(pedigree,"%d",&peds[i].sexes[j]);
      for(l=0;l<MAP.nm;l++)
	fscanf(pedigree,"%d%d",&peds[i].genos[j][l][0],&peds[i].genos[j][l][1]);
	  for(l=0;l<ncov;l++)
	    fscanf(pedigree,"%lf",&peds[i].covariates.mat[j][l]);
	  fscanf(pedigree,"%lf",&peds[i].phenos[j]);
    }

/*     for(i=0;i<npeds;i++) */
/*       { */
/* 	j=0; */
/* 	printf("%7.1f\t%7d\t%7d\t%7d\n",peds[i].id,peds[i].p_ids[j], */
/* 	       peds[i].f_ids[j],peds[i].m_ids[j]); */
/*       } */

  return ind;
  
}

